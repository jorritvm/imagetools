Imagetools v1.1
---------------

By Jorrit Vander Mynsbrugge
http://jayke.ulyssis.be/homepage


Description:
------------

Imagetools lets you number, rename and resize your pictures in a few simple clicks. 


Installation instructions:
--------------------------

Windows:
-Run the installer, no dependencies are required.

Linux:
Depends on python, pyqt and qt

-Source package:
--Extract
--install by typing: python setup.py install
--run by typing: imagetools

-Pacman package (arch linux):
--Install via pacman -U
--Run by typing imagetools


Contact info:
-------------

Jorrit Vander Mynsbrugge
jorrit.vm@gmail.com
http://jayke.ulyssis.be/homepage