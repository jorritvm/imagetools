#!/usr/bin/python
############################################################################
#    Copyright (C) 2011 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@gmail.com                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from PyQt4.QtGui import *
from PyQt4.QtCore import *

from resource import *

from thumbnailbrowser.ThumbnailView import *
from thumbnailbrowser.ThumbnailModel import *

from imageselection.ImageSelectionModel import *
from imageselection.ImageSelectionView import *

from imageoperations.Number import *
from imageoperations.Rename import *
from imageoperations.Resize import *
from imageoperations.WebAlbum import *


class MainWindow(QMainWindow):
    
    def __init__(self, parent = None):
        super(MainWindow,self).__init__(parent)

        """"""""""""""""""""""""""""""""""""
        """init debug"""
        #imagesPath = "C:/Users/jorrit/development/python/imagetools/images"
        imagesPath = ""
        """"""""""""""""""""""""""""""""""""
        
        self.setupThumbnailBrowser(imagesPath)
        self.setupImageSelection()
        self.setupUi()
        self.setupTree()
        self.setupEdit()
        self.setupEditTreeLink()
        self.setupZoomButtons()    
        self.setupSelectionButtons()
        self.setupToolButtons()
        
        """"""""""""""""""""""""""""""""""""
        """init debug"""
        self.uiPath.setText(imagesPath)
        self.treeSelectionModel.selectionChanged.connect(self.handleSelectionChange)
        """"""""""""""""""""""""""""""""""""    
        
    def test(self):
        pass

    
    #===========================================================================
    # TREE AND EDIT MGT
    #===========================================================================
            
    def setupTree(self):
        """file system model"""
        self.fsm = QFileSystemModel(self)
        self.fsm.setRootPath("")
        self.fsm.setFilter(QDir.Dirs | QDir.NoDotAndDotDot)
   
        """modify the treeview to show only the first column"""                
        self.uiTree.setModel(self.fsm)
        for i in range(3):
            self.uiTree.setColumnHidden(i+1, True)
        self.uiTree.header().hide()

        """link the selection model to an instance variable for later use"""
        self.treeSelectionModel = self.uiTree.selectionModel()
        
        """add a horizontal scrollbar to the tree"""
        self.uiTree.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn) #this probably can be deleted  

        """if the current item is changed, only expand up to the new item"""
        self.treeSelectionModel.currentChanged.connect(self.expandToCurrent)
           
      
    def setupEdit(self):
        """completer used by the lineedit"""
        self.completer = QCompleter(self)
        self.completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)
        self.completer.setModel(self.fsm)
        
        """debug"""
        self.popup = self.completer.popup()
        self.popup.setMinimumSize(QSize(0,100))
        
        self.uiPath.setCompleter(self.completer)
        
        self.uiPath.tabPressed.connect(self.tabAction)
        #self.connect(self.uiPath,SIGNAL("tabPressed"),self.tabAction)
    

    def setupEditTreeLink(self):
        """edit --> tree"""
        txt = self.uiPath.text()
        self.uiPath.returnPressed.connect(self.setUiTree)
        
        """tree --> edit"""
        self.treeSelectionModel.currentChanged.connect(self.setFilePath)
        
        """tree --> browser"""
        self.treeSelectionModel.currentChanged.connect(self.showFolderContents)
        
        
    def setFilePath(self, currentModelIndex, oldModelIndex):
        self.uiPath.setText(self.fsm.filePath(currentModelIndex))
        
        
    def setUiTree(self):
        path = self.uiPath.text()
        check = QFileInfo(path).isDir()
        if check:
            modelIndex = self.fsm.index(path)
            if self.fsm.fileName(modelIndex) !=  "":
                self.treeSelectionModel.setCurrentIndex(modelIndex, QItemSelectionModel.ClearAndSelect)      
                
                          
    def showFolderContents(self, currentModelIndex, oldModelIndex):
        """get folder to display"""
        folder = self.fsm.filePath(currentModelIndex)
        #self.browserModel.setRootPath(folder)
        self.fsm.setRootPath(self.fsm.filePath(currentModelIndex))
        #self.uiFileBrowser.setRootIndex(currentModelIndex) #self.fsm.index(QDir.currentPath())
        
        """setup a new thumbnailbrowser but make sure the old one's 2nd thread is dead"""
        if self.tm.isGeneratorBusy():
            if self.tm.interuptGenerator():
                self.setupNewThumbnailModel(folder)
        else:
            self.setupNewThumbnailModel(folder)
    
    
    def tabAction(self):
        prefix = self.completer.completionPrefix()
        text = self.uiPath.text()
        if prefix != text:
            #we hebben met de pijltjes een andere dropdown optie gekozen
            next = text
        else: 
            next = self.completer.currentCompletion()
        if QFileInfo(next).isDir():
            next = next + "\\"
        self.uiPath.setText(next)
        self.completer.setCompletionPrefix(next)
    
    
    def expandToCurrent(self, currentModelIndex, oldModelIndex):
        oldPath = self.fsm.filePath(oldModelIndex)
        newPath = self.fsm.filePath(currentModelIndex)

        if oldPath in newPath:
            """either the new path is a subfolder of the new path..."""
            self.uiTree.expand(currentModelIndex)
        elif newPath in oldPath:
            """or the new path is a parent folder..."""
            index = oldModelIndex
            while oldPath != newPath:
                self.uiTree.collapse(index)
                index = self.fsm.parent(index)
                oldPath = self.fsm.filePath(index)  
        else:
            """or we start collapsing until they have the same joined path"""
            index = oldModelIndex
            while index != QModelIndex():
                self.uiTree.collapse(index)
                index = self.fsm.parent(index)
                tempPath = self.fsm.filePath(index)
                if tempPath in newPath:
                    """here they have common path, so we break the collapse loop"""
                    break
            """and even if the loop continues all the way up the tree, this still works out fine for us..."""
            
            """time to expand the new path"""
            self.uiTree.expand(currentModelIndex)
                
        """resize width of column every time expansion/collapsing happens"""
        self.uiTree.resizeColumnToContents(0)
        
        
    def handleSelectionChange(self, new, old):
        """since the selection model is annoying we make sure it always selects the 'current' item"""
        currentModelIndex = self.treeSelectionModel.currentIndex()
        """although this is messy, just go with it ;-) """
        if len(new.indexes()) > 0:
            selectedModelIndex = new.indexes()[0]
            if currentModelIndex != selectedModelIndex:
                self.treeSelectionModel.select(currentModelIndex, QItemSelectionModel.Clear)
                self.treeSelectionModel.select(currentModelIndex, QItemSelectionModel.Select)


    #===========================================================================
    # THUMBNAILBROWSER MGT
    #===========================================================================
    
    def setupThumbnailBrowser(self,imagesPath):
        """create the thumbnailviewer (model/view based)"""
        self.tv = ThumbnailView()
        #self.tv.setGeometry(QRect)
        
        self.setupNewThumbnailModel(imagesPath)
        
        
    def setupNewThumbnailModel(self, imagesPath):
        """create the model"""
        self.tm = ThumbnailModel(imagesPath)
        
        """link the model to the view"""
        self.tv.setModel(self.tm)
        
    def setupZoomButtons(self):
        self.uiZoomIn.pressed.connect(lambda: self.tv.adjustIconSize("+"))
        self.uiZoomOut.pressed.connect(lambda: self.tv.adjustIconSize("-"))
    
    
    def setupImageSelection(self):
        self.imageSelectionView = ImageSelectionView()
        self.imageSelectionModel = ImageSelectionModel()
        self.imageSelectionView.setModel(self.imageSelectionModel)
        #self.imageSelectionModel.dataChanged.connect(self.imageSelectionView.resizeColumns)
        self.imageSelectionModel.rowsInserted.connect(self.imageSelectionView.resizeColumns)
        self.imageSelectionModel.rowsRemoved.connect(self.imageSelectionView.resizeColumns)
        

    
    #===========================================================================
    # SELECTION BUTTONS ACTIONS
    #===========================================================================
    
    def setupSelectionButtons(self):
        self.uiBtnAdd.pressed.connect(self.addButtonAction)
        self.uiBtnRemove.pressed.connect(self.removeButtonAction)
        self.uiBtnAddAll.pressed.connect(self.addAllButtonAction)
        self.uiBtnClear.pressed.connect(self.clearButtonAction)    
        
            
    def addButtonAction(self):
        """get the selected items and pass them to the itemselectionmodel"""
        selectedImages = self.tv.getSelectedItemsAbsolutePath()
        self.imageSelectionModel.addImages(selectedImages)
         
    def removeButtonAction(self):
        """tell the view to remove the items it has selected"""
        self.imageSelectionView.removeImages()
    
    def addAllButtonAction(self):
        """get a list of all the items and pass them to the itemselectionmodel"""
        allImages = self.tv.getAllItemsAbsolutePath()
        self.imageSelectionModel.addImages(allImages)   
        
    def clearButtonAction(self):
        """wipe the selection clean"""
        self.imageSelectionView.clearSelection()


    #===========================================================================
    # TOOL BUTTONS ACTIONS
    #===========================================================================
    
    def setupToolButtons(self):
        self.uiBtnNumber.pressed.connect(self.numberButtonAction)
        self.uiBtnRename.pressed.connect(self.renameButtonAction)
        self.uiBtnResize.pressed.connect(self.resizeButtonAction)
        self.uiBtnWebAlbum.pressed.connect(self.webAlbumButtonAction)
    
            
    def numberButtonAction(self):
        if self.imageSelectionModel.rowCount(QModelIndex()) == 0:
            QMessageBox.warning(self, "No selection", "Create a selection first.")
        else: 
            """create the dialog and extract the user's settings"""
            num = Number()
            settings = None
            if num.exec_():
                settings = num.getSettings()
                
                """get the current selected files"""
                files = self.imageSelectionModel.getCurrentSelection() #QFileInfo objects
                
                """start the rename procedure"""
                trackChanges = num.renameFiles(files, settings)
                
                """update the current thumbnailmodel and the imageselectionmodel!!!"""
                self.tm.adaptToRename(trackChanges)
                self.imageSelectionModel.adaptToRename(trackChanges)
        
        
    def renameButtonAction(self):
        if self.imageSelectionModel.rowCount(QModelIndex()) == 0:
            QMessageBox.warning(self, "No selection", "Create a selection first.")
        else: 
            """get the current selected files"""
            files = self.imageSelectionModel.getCurrentSelection() #QFileInfo objects
            
            """create the dialog"""
            ren = Rename(files)
            ren.exec_()
           
            """the dialog is ready now, we should update the application with the new filenames"""
            trackChanges = ren.getChanges()
            self.tm.adaptToRename(trackChanges)
            self.imageSelectionModel.adaptToRename(trackChanges)
       
    
    def resizeButtonAction(self):
        if self.imageSelectionModel.rowCount(QModelIndex()) == 0:
            QMessageBox.warning(self, "No selection", "Create a selection first.")
        else: 
            """get the current selected files"""
            files = self.imageSelectionModel.getCurrentSelection() #QFileInfo objects
        
            """create the dialog"""
            res = Resize(files)
            res.exec_()
            
            
    def webAlbumButtonAction(self):
        if self.imageSelectionModel.rowCount(QModelIndex()) == 0:
            QMessageBox.warning(self, "No selection", "Create a selection first.")
        else: 
            """get the current selected files"""
            files = self.imageSelectionModel.getCurrentSelection() #QFileInfo objects
        
            """create the dialog"""
            wa = WebAlbum(files)
            wa.exec_()
            
            

            
    #===========================================================================
    # SET UP UI
    #===========================================================================
        
    def setupUi(self):
        """create centralWidget first"""
        self.centralWidget = QWidget(self)

        self.setWindowTitle("Imagetools")

        """create treeview (modelbased)"""
        self.uiTree = QTreeView()
        
        """create path input lineedit"""
        self.uiPath = JLineEdit()
        
        """create the main browser"""
        #self.uiFileBrowser = QTreeView()
        self.uiFileBrowser = self.tv
        
        """create the selectionbrowser"""
        self.uiSelectionBrowser = self.imageSelectionView
        
        """create toolbuttons"""
        self.uiBtnNumber = QPushButton("Number")
        self.uiBtnRename = QPushButton("Rename")
        self.uiBtnResize = QPushButton("Resize")
        self.uiBtnWebAlbum = QPushButton("Web Album")
        BtnList = [self.uiBtnNumber, self.uiBtnRename, self.uiBtnResize, self.uiBtnWebAlbum]
        
        """layout buttons"""
        self.uiLayoutBtns = QHBoxLayout()
        for Btn in BtnList:
            self.uiLayoutBtns.addWidget(Btn)
        self.btnSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.uiLayoutBtns.addItem(self.btnSpacer)

        """create selectionbox buttons"""
        self.uiBtnAdd = QPushButton("Add")
        self.uiBtnRemove = QPushButton("Remove")
        self.uiBtnAddAll = QPushButton("Add All")
        self.uiBtnClear = QPushButton("Clear")
        BtnList2 = [self.uiBtnAdd, self.uiBtnRemove, self.uiBtnAddAll, self.uiBtnClear]
        self.uiZoomIn = QPushButton("+")
        self.uiZoomOut = QPushButton("-")
        BtnList3 = [self.uiZoomIn, self.uiZoomOut]
        
        """layout buttons"""
        self.uiLayoutBtns2 = QHBoxLayout()
        for Btn in BtnList2:
            self.uiLayoutBtns2.addWidget(Btn)
        self.btnSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.uiLayoutBtns2.addItem(self.btnSpacer)
        for Btn in BtnList3:
            Btn.setMaximumWidth(25) 
            self.uiLayoutBtns2.addWidget(Btn)
        
        """rechtse layout"""
        self.uiLayoutRight = QVBoxLayout()
        self.uiLayoutRight.addWidget(self.uiFileBrowser)
        self.uiLayoutRight.addLayout(self.uiLayoutBtns2)
        self.uiLayoutRight2 = QVBoxLayout()
        self.uiLayoutRight2.addWidget(self.uiSelectionBrowser)
        self.uiLayoutRight2.addLayout(self.uiLayoutBtns)
        self.uiLayoutRight.setMargin(0)
        self.uiLayoutRight2.setMargin(0)
        self.tempWidget = QWidget()
        self.tempWidget.setLayout(self.uiLayoutRight)
        self.tempWidget2 = QWidget()
        self.tempWidget2.setLayout(self.uiLayoutRight2)
        
        self.uiLayoutLeft = QVBoxLayout()
        self.uiLayoutLeft.addWidget(self.uiPath)
        self.uiLayoutLeft.addWidget(self.uiTree)
        self.uiLayoutLeft.setMargin(0)
        self.tempWidget3 = QWidget()
        self.tempWidget3.setLayout(self.uiLayoutLeft)
        
        """horizontal splitter"""
        self.vsplitter = QSplitter(Qt.Vertical)
        self.vsplitter.addWidget(self.tempWidget)
        self.vsplitter.addWidget(self.tempWidget2)
        
        """vertical splitter"""
        self.hsplitter = QSplitter()
        self.hsplitter.addWidget(self.tempWidget3)
        self.hsplitter.addWidget(self.vsplitter)
    
        self.gridLayout = QGridLayout(self.centralWidget)
        self.gridLayout.addWidget(self.hsplitter)
        
        self.setCentralWidget(self.centralWidget)
        
        """size"""
        self.resize(800, 600)
        self.vsplitter.setSizes([300,100]) #this gives us a nice startup size distribution
        self.hsplitter.setSizes([100,300]) #this gives us a nice startup size distribution
        #sizepol = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        #self.uiTree.setSizePolicy(sizepol)
        
        self.setWindowIcon(QIcon(":/appicon.ico"))
        
class JLineEdit(QLineEdit):
    """it's important to define new style pyqt signals in the class declaration space, not the constructor!!!"""
    tabPressed = pyqtSignal()
    
    def __init__(self, *args):
        QLineEdit.__init__(self, *args)
        
        
    def event(self, event):
        #this class has new signals to act when certain keys are pressed 
        if (event.type()==QEvent.KeyPress) and (event.key()==Qt.Key_Tab):
            self.tabPressed.emit()
            #self.emit(SIGNAL("tabPressed"))
            return True

        return QLineEdit.event(self, event)

if __name__ == "__main__":
    
    import sys
    app = QApplication(sys.argv)
    
    main = MainWindow()
    main.show()
    
    sys.exit(app.exec_())
        


