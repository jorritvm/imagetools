'''
Created on 24-aug.-2011

@author: jorrit
'''

from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys

from ThumbnailView import *
from ThumbnailModel import *

if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    
    #create view
    tv = ThumbnailView()
    
    #create model
    path = "C:/Users/jorrit/development/python/imagetools/images"
    tm = ThumbnailModel(path)

    #link model to view
    tv.setModel(tm)

    #show view
    tv.show()
    
    sys.exit(app.exec_())
    