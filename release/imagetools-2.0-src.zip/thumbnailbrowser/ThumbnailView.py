'''
Created on 24-aug.-2011

@author: jorrit
'''

from PyQt4.QtGui import *
from PyQt4.QtCore import *

class ThumbnailView(QListView):
    def __init__(self, parent = None):
        QListView.__init__(self, parent)
        
        """change the viewmode to iconmode instead of listmode"""
        self.setViewMode(QListView.IconMode)
        
        """set the icon size"""
        self.iconSizes = [100,135,181,245]
        self.iconSizePosition = 2
        self.setIconMaxSize()
        
        """add some spacing around the elements"""
        self.setSpacing(10)
        
        """wrap the items when there are too many to layout horizontally"""
        self.setWrapping(True)
        
        """set the automatic resize to adjust instead of fixed"""
        self.setResizeMode(QListView.Adjust)
        
        """set the view to allow multiple selection"""
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        
        """debug""" 
        #self.resize(QSize(1000,500))
    
        
    def adjustIconSize(self,direction):
        if direction == "+":
            newPos = self.iconSizePosition + 1 
        elif direction == "-":
            newPos = self.iconSizePosition - 1
        
        """make sure we don't try to go out of bounds of our sizes list"""
        if newPos < 0 or newPos > len(self.iconSizes)-1:
            newPos = self.iconSizePosition

        self.iconSizePosition = newPos
        self.setIconMaxSize()
        
    
    def setIconMaxSize(self):
        """here we really set the iconSize, the view will update automaticly"""
        size = self.iconSizes[self.iconSizePosition]
        self.setIconSize(QSize(size,size*9/16))
        
    def getSelectedItemsAbsolutePath(self):
        absolutePathList = list()
        
        selmod = self.selectionModel()
        imageSelection = selmod.selectedIndexes()
                
        for imageIndex in imageSelection:
            tmp = self.model().data(imageIndex,"getAbsolutePath")
            absolutePathList.append(tmp)
        
        return absolutePathList
    
    def getAllItemsAbsolutePath(self):
        absolutePathList = self.model().absolutePathImages[:]
        return absolutePathList