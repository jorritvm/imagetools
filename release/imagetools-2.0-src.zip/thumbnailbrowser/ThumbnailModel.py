'''
Created on 24-aug.-2011

@author: jorrit
'''

from PyQt4.QtGui import *
from PyQt4.QtCore import *

class ThumbnailModel(QAbstractTableModel):
    
    def __init__(self, path, parent = None):
        QAbstractTableModel.__init__(self, parent)
        
        """set a directory model with appropriate filters to get the image info"""
        self.dirModel = QDir(path)
        self.setDirModelFilters(["*.jpg","*.jpeg","*.png","*.bmp"])

        """create the DATA the model will use"""
        self.images = self.dirModel.entryList()
        self.absolutePathImages = list()
        for fileName in self.images:
            self.absolutePathImages.append(self.dirModel.absoluteFilePath(fileName))        
        
        """create thumbnail DATA structure"""
        self.thumbnails = dict()
               
        """now calculate the real thumbnails in a seperate thread"""
        self.lock = QMutex()
        self.thumbnailGenerator = ThumbnailGenerator(self.lock, self) #subclass of QThread
        self.thumbnailGenerator.newThumbnailReady.connect(self.updateThumbnail) 
        
        """always create thumbs of 245x245, the view can still show smaller versions as desired"""
        self.thumbnailGenerator.initialize(self.absolutePathImages, QSize(245,245)) 
        if self.thumbnailGenerator.isRunning():
            pass
            #print("busy calculating in thread - get back to me later")
        else:
            self.thumbIndex = 0
            self.thumbnailGenerator.start()
            
            
    def isGeneratorBusy(self):
        return self.thumbnailGenerator.isRunning()
    
    
    def interuptGenerator(self):
        self.thumbnailGenerator.abortNow()
        while self.thumbnailGenerator.isRunning():
            pass
        return True
        
        
    ## MODEL FUNCTIONALITY
    def setDirModelFilters(self, filters):
        self.dirModel.setNameFilters(filters)


    def updateThumbnail(self, icon):
        self.thumbnails[self.images[self.thumbIndex]] = icon
        index = self.createIndex(self.thumbIndex, 0)
        self.thumbIndex += 1
        self.dataChanged.emit(index, index)

  
    def adaptToRename(self, trackChanges):
        i=0
        for absolutePathImage in self.absolutePathImages:
            if absolutePathImage in trackChanges.keys():
                """change the underlying data structure"""
                newAbsName = trackChanges[self.absolutePathImages[i]]
                newFi = QFileInfo(newAbsName)
                newName = newFi.fileName()
                                
                oldAbsName = self.absolutePathImages[i] 
                oldName = self.images[i]
                                
                self.images[i] = newName
                self.absolutePathImages[i] = newAbsName
                self.thumbnails[newName] = self.thumbnails[oldName]
                del self.thumbnails[oldName]
                
                """create a modelindex and let the views now that the data is changed"""
                index = self.createIndex(i, 0)
                self.dataChanged.emit(index, index)
                
            i+=1
            
            
            
    ## ABSTRACT MODEL REIMPLEMENATION
    """reimplement the abstract rowcount function"""
    def rowCount(self, index):
        return len(self.images)
    
    """reimplement the abstract columncount function"""
    def columnCount(self, index):
        return 1
    
    """reimplement the abstract data function"""
    def data(self, index, role):
        
        if role == Qt.DisplayRole:
            """the display role gives the view the filename"""
            return self.images[index.row()]
        
        if role == Qt.DecorationRole:
            """the decoration role gives the view the thumbnail"""
            fileName = self.images[index.row()]
            if fileName in self.thumbnails.keys():
                return self.thumbnails[fileName]
            else:
                px = QPixmap(480,270) #take this dummy thumbnail large enough
                px.fill(QColor(255,255,255)) #makes sure it's white
                return QIcon(px)
        
        if role == "getAbsolutePath":
            return self.absolutePathImages[index.row()]
            
        
class ThumbnailGenerator(QThread):
    
    newThumbnailReady = pyqtSignal(QIcon)
    
    def __init__(self, lock, parent=None):
        QThread.__init__(self, parent)
        self.lock = lock
        self.abort = False
        
    
    def initialize(self, absolutePathImages, size):
        self.absolutePathImages = absolutePathImages
        self.size = size

    """once we set the abort flag, the generator will stop when he's finished the latest resizing"""
    def abortNow(self):
        self.abort = True

    def run(self):
        
        for absolutePathImage in self.absolutePathImages:
            if self.abort:
                break
            pixmap = QPixmap(absolutePathImage)
            try:
                self.lock.lock()
                pixmap = pixmap.scaled(self.size, Qt.KeepAspectRatio, Qt.FastTransformation) 
                icon = QIcon(pixmap)
                self.newThumbnailReady.emit(icon) 
            finally:
                self.lock.unlock()       

        
        