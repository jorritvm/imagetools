# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\jorrit\development\python\imagetools\src\imageoperations\Renameui.ui'
#
# Created: Thu Sep 29 17:14:16 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Rename(object):
    def setupUi(self, Rename):
        Rename.setObjectName(_fromUtf8("Rename"))
        Rename.resize(442, 456)
        self.vboxlayout = QtGui.QVBoxLayout(Rename)
        self.vboxlayout.setObjectName(_fromUtf8("vboxlayout"))
        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName(_fromUtf8("hboxlayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)
        self.labelImagePreview = QtGui.QLabel(Rename)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.labelImagePreview.sizePolicy().hasHeightForWidth())
        self.labelImagePreview.setSizePolicy(sizePolicy)
        self.labelImagePreview.setText(_fromUtf8(""))
        self.labelImagePreview.setAlignment(QtCore.Qt.AlignCenter)
        self.labelImagePreview.setObjectName(_fromUtf8("labelImagePreview"))
        self.hboxlayout.addWidget(self.labelImagePreview)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem1)
        self.vboxlayout.addLayout(self.hboxlayout)
        self.gridlayout = QtGui.QGridLayout()
        self.gridlayout.setObjectName(_fromUtf8("gridlayout"))
        self.label = QtGui.QLabel(Rename)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridlayout.addWidget(self.label, 0, 0, 1, 1)
        self.labelOldName = QtGui.QLabel(Rename)
        self.labelOldName.setText(_fromUtf8(""))
        self.labelOldName.setObjectName(_fromUtf8("labelOldName"))
        self.gridlayout.addWidget(self.labelOldName, 0, 1, 1, 1)
        self.label_5 = QtGui.QLabel(Rename)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridlayout.addWidget(self.label_5, 1, 0, 1, 1)
        self.labelExtension = QtGui.QLabel(Rename)
        self.labelExtension.setText(_fromUtf8(""))
        self.labelExtension.setObjectName(_fromUtf8("labelExtension"))
        self.gridlayout.addWidget(self.labelExtension, 1, 1, 1, 1)
        self.label_4 = QtGui.QLabel(Rename)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridlayout.addWidget(self.label_4, 2, 0, 1, 1)
        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setObjectName(_fromUtf8("hboxlayout1"))
        self.spinSkipLeft = QtGui.QSpinBox(Rename)
        self.spinSkipLeft.setObjectName(_fromUtf8("spinSkipLeft"))
        self.hboxlayout1.addWidget(self.spinSkipLeft)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.hboxlayout1.addItem(spacerItem2)
        self.gridlayout.addLayout(self.hboxlayout1, 2, 1, 1, 1)
        self.label_2 = QtGui.QLabel(Rename)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridlayout.addWidget(self.label_2, 3, 0, 1, 1)
        self.editNewName = QtGui.QLineEdit(Rename)
        self.editNewName.setObjectName(_fromUtf8("editNewName"))
        self.gridlayout.addWidget(self.editNewName, 3, 1, 1, 1)
        self.label_3 = QtGui.QLabel(Rename)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridlayout.addWidget(self.label_3, 4, 0, 1, 1)
        self.labelPreview = QtGui.QLabel(Rename)
        self.labelPreview.setText(_fromUtf8(""))
        self.labelPreview.setObjectName(_fromUtf8("labelPreview"))
        self.gridlayout.addWidget(self.labelPreview, 4, 1, 1, 1)
        self.vboxlayout.addLayout(self.gridlayout)
        self.hboxlayout2 = QtGui.QHBoxLayout()
        self.hboxlayout2.setObjectName(_fromUtf8("hboxlayout2"))
        self.buttonSaveNext = QtGui.QPushButton(Rename)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonSaveNext.sizePolicy().hasHeightForWidth())
        self.buttonSaveNext.setSizePolicy(sizePolicy)
        self.buttonSaveNext.setObjectName(_fromUtf8("buttonSaveNext"))
        self.hboxlayout2.addWidget(self.buttonSaveNext)
        self.buttonSkipNext = QtGui.QPushButton(Rename)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonSkipNext.sizePolicy().hasHeightForWidth())
        self.buttonSkipNext.setSizePolicy(sizePolicy)
        self.buttonSkipNext.setObjectName(_fromUtf8("buttonSkipNext"))
        self.hboxlayout2.addWidget(self.buttonSkipNext)
        self.vboxlayout.addLayout(self.hboxlayout2)

        self.retranslateUi(Rename)
        QtCore.QMetaObject.connectSlotsByName(Rename)

    def retranslateUi(self, Rename):
        Rename.setWindowTitle(QtGui.QApplication.translate("Rename", "Rename images", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Rename", "Old Name", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("Rename", "Extension", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Rename", "Skip left", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Rename", "New Name", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("Rename", "Preview", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonSaveNext.setText(QtGui.QApplication.translate("Rename", "Save - Next", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonSkipNext.setText(QtGui.QApplication.translate("Rename", "Skip - Next", None, QtGui.QApplication.UnicodeUTF8))

