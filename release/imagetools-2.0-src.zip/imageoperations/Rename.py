from PyQt4.QtCore import *
from PyQt4.QtGui import *
from imageoperations.Renameui import *

class Rename(QDialog, Ui_Rename): 
    
    def __init__(self, files, parent=None):
        QDialog.__init__(self, parent)
        self.setupUi(self)
        
        #dialog
        #self.buttonStartNumbering.clicked.connect(self.accept)
        #self.buttonStartNumbering.setDefault(True)
    
        self.files = files #QFileInfo objects
        self.trackChanges = dict()

        self.busy = 0
        self.lock = QMutex()
        self.BigThumbnailGenerator = BigThumbnailGenerator(self.lock)

        self.setupSlots()
        self.imageIndex = 0
        self.loadImage()       
        

    def setupSlots(self):
        self.BigThumbnailGenerator.finishedImage.connect(self.displayThumbnail)
        self.editNewName.textEdited.connect(self.adjustPreview)
        self.spinSkipLeft.valueChanged.connect(self.adjustPreview)
        self.buttonSaveNext.clicked.connect(self.saveNext)
        self.buttonSkipNext.clicked.connect(self.gotoNext)
        #self.editNewName.returnPressed.connect(self.saveNext) #this already works out of the box - weird...Is QDialog the reason?
    
    
    def loadImage(self):
        if len(self.files) > 0:
            fi = self.files[self.imageIndex]
            self.labelOldName.setText(fi.baseName())
            self.labelExtension.setText(fi.completeSuffix())
            self.editNewName.clear()
            self.editNewName.setFocus() #todo: validate if this works
            path = fi.absoluteFilePath()
            self.showThumbnail(path)
        
        
    def showThumbnail(self, path):
        self.BigThumbnailGenerator.initialize(path, self.height())
        if self.BigThumbnailGenerator.isRunning():
            #print("busy, flag set")
            #set the flag if the generator is busy
            self.busy = 1
        else:
            #print("starting generator now!")
            #or start the generator if it's not
            self.BigThumbnailGenerator.start()
        
        self.labelImagePreview.setText("creating preview...")


    def displayThumbnail(self, scaledImage):
        if self.busy == 1:
            #print("generator was busy so we quickly calculate it now!")
            #if the generator didn't start on the last demanded thumbnail because it was busy, we calculate it here
            self.thumbnailgenerator.wait()
            self.thumbnailgenerator.start()
            self.busy = 0
        else:
            #print("image ready - showing it")
            #if the generator did finish the correct image we can show it now
            self.labelImagePreview.setPixmap(QPixmap.fromImage(scaledImage))
  
    
    def adjustPreview(self):
        """we create the virtual new filename to show a preview"""
        leftKeep = self.spinSkipLeft.value()
        oldName = self.labelOldName.text()
        oldNameKeep = oldName[:leftKeep]
        newPart = self.editNewName.text()
        extension  = "." + self.labelExtension.text()
        newName = oldNameKeep + newPart + extension
        self.labelPreview.setText(newName)
       
       
    def saveNext(self):
        """get new filename"""
        newName = self.labelPreview.text()
                
        if newName == '':
            QMessageBox.warning(self, "Invalid filename", "You need to enter a new filename first!")
        else:               
            """create file object"""
            fileInfo = self.files[self.imageIndex]
            file = QFile(fileInfo.absoluteFilePath())

            oldName = fileInfo.absoluteFilePath()
            newName = fileInfo.absolutePath() + "/" + newName 
            
            x = file.rename(newName)
            #print("-"+str(x))
            if x:
                """rename succesful -> let the program know"""
                self.trackChanges[oldName] = newName
                self.gotoNext()
            else:
                QMessageBox.warning(self, "Invalid filename", "Rename failed.")

    
    def gotoNext(self):
        newIndex = self.imageIndex + 1
        if newIndex >= len(self.files):
            QMessageBox.information(self, "End of selection", "End of selection reached.")
        else:
            self.imageIndex = newIndex
            self.loadImage()


    def getChanges(self):
        return self.trackChanges


    
class BigThumbnailGenerator(QThread):
    
    finishedImage = pyqtSignal(QImage)
    
    def __init__(self, lock, parent=None):
        QThread.__init__(self, parent)
        self.lock = lock
        
    def initialize(self, path, height):
        self.path = path
        self.height = height
                
    def run(self):
        imagepreview = QImage(self.path)
        
        h = self.height / 2
        transformationType = Qt.FastTransformation
        try:
            self.lock.lock()
            scaledImage = imagepreview.scaledToHeight(h,transformationType)
        finally:
            self.lock.unlock()

        self.finishedImage.emit(scaledImage)
