from PyQt4.QtCore import *
from PyQt4.QtGui import *
from imageoperations.Resizeui import *

class Resize(QDialog, Ui_Resize):
    
    def __init__(self, files, parent=None):
        QDialog.__init__(self, parent)
        self.setupUi(self)
        
        self.files = files #QFileInfo objects
              
        self.busy = 0
        self.lock = QMutex()
        self.Resizer = Resizer(self.lock)
        
        self.setupSlots()
        
        
        
    def setupSlots(self):
        self.sliderQuality.valueChanged.connect(self.adjustSlider)
        self.Resizer.finishedAnotherResize.connect(self.updateProgressBar)
        self.buttonStartResize.pressed.connect(self.startResize)
        self.buttonCancelResize.pressed.connect(self.interuptResize)
        
        
    def adjustSlider(self, x):
        self.labelQuality.setText(str(x)+" %")      


    def updateProgressBar(self, value):
        self.progressBar.setValue(value)
        
        
    def startResize(self):
        #print("starting resize")
        settings = dict()
        error = False
        self.Resizer.unlockThread()
        
        """prefix - suffix"""
        settings["prefix"] = self.editNamePrefix.text()
        settings["suffix"] = self.editNameSuffix.text()
        
        """the quality is 100 - the compression"""
        settings["quality"] = 100 - self.spinQuality.value()
        
        """the smoothing parameter"""
        if self.checkSmooth.isChecked():
            settings["smooth"] = Qt.SmoothTransformation
        else:
            settings["smooth"] = Qt.FastTransformation
        
        """the size settings"""
        if self.rb1.isChecked():
            settings["rb"] = 1
            settings["rb1"] = self.comboBox.currentIndex()
        elif self.rb2.isChecked():
            settings["rb"] = 2
            settings["rb2"] = self.sliderQuality.value() 
        elif self.rb3.isChecked():
            settings["rb"] = 3
            
            slist = self.editSize.text().split("x")
            if len(slist) == 2:
                w = int(slist[0])
                h = int(slist[1])
                settings["rb3"] = (w,h)
            else:
                error = True
                QMessageBox.warning(self, "Invalid format", "Enter size formatted like 'WIDTHxHEIGHT'!")  
        
        """pass the settings and the files to the resize thread"""
        if not error:
            #print("no errors, printing the settings now:")
            #print(settings)
            self.Resizer.initialize(self.files, settings)
            self.Resizer.start()
        

    def interuptResize(self):
        self.Resizer.abortNow()
            

class Resizer(QThread):
    
    finishedAnotherResize = pyqtSignal(int)
    
    def __init__(self, lock, parent=None):
        QThread.__init__(self, parent)
        self.lock = lock
        self.abort = False
        
    def initialize(self, files, settings):
        #print("thread: init ok")
        self.files = files
        self.settings = settings

    """once we set the abort flag, the generator will stop when he's finished the latest resizing"""
    def abortNow(self):
        #print("thread: abort initiated")
        self.abort = True
        
    def unlockThread(self):
        self.abort = False
                
    def run(self):
        #print("thread: starting resize")
        i = 0
        total = len(self.files)
        
        for fileInfo in self.files:
            if self.abort:
                #print("aborting...")
                break
            
            """create the filename of the resized file"""
            newName = ""
            newName += self.settings["prefix"]
            newName += fileInfo.baseName()
            newName += self.settings["suffix"]
            newName += "."
            newName += fileInfo.completeSuffix()
            newNameAbs = fileInfo.absolutePath() + "/" + newName
            
            #print(fileInfo.fileName())
            #print(newName)
            #print(fileInfo.absoluteFilePath())
            #print(newNameAbs)
            
            """we create the image first"""
            path = fileInfo.absoluteFilePath()
            image = QImage(path)
            
            """size can be are file specific so we define it here"""
            if self.settings["rb"] == 1:
                if self.settings["rb1"] == 0:
                    w = 1280 
                    h = 1024
                elif self.settings["rb1"] == 1:
                    w = 1024 
                    h = 786
                elif self.settings["rb1"] == 2:
                    w = 800 
                    h = 600
                elif self.settings["rb1"] == 3:
                    w = 640 
                    h = 480
                elif self.settings["rb1"] == 4:
                    w = 320 
                    h = 240
                elif self.settings["rb1"] == 5:
                    w = 160 
                    h = 120
            elif self.settings["rb"] == 2:
                sizeproc = self.settings["rb2"] 
                w = image.width() * sizeproc / 100
                h = image.height() * sizeproc / 100
            elif self.settings["rb"] == 3:
                w = self.settings["rb3"][0]
                h = self.settings["rb3"][1]

            #resize  
            newImage = image.scaled(w, h, Qt.KeepAspectRatio, self.settings["smooth"])
            #if newImage.save(newNameAbs, "0", self.settings["quality"]):
            if newImage.save(newNameAbs):
                pass
                #print("success")
            else:
                pass
                #print("failed")
            
            i += 1
            
            #progressbar aanpassen
            progress = i * 100 / total            
            self.finishedAnotherResize.emit(progress)
            
            
         
       
        
