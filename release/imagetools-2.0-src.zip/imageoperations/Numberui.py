# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\jorrit\development\python\imagetools\src\imageoperations\Numberui.ui'
#
# Created: Thu Sep 29 17:14:14 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Number(object):
    def setupUi(self, Number):
        Number.setObjectName(_fromUtf8("Number"))
        Number.resize(262, 211)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Number.sizePolicy().hasHeightForWidth())
        Number.setSizePolicy(sizePolicy)
        self.gridLayout = QtGui.QGridLayout(Number)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.groupBox_2 = QtGui.QGroupBox(Number)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupBox_2.sizePolicy().hasHeightForWidth())
        self.groupBox_2.setSizePolicy(sizePolicy)
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.gridlayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridlayout.setObjectName(_fromUtf8("gridlayout"))
        self.radioPre = QtGui.QRadioButton(self.groupBox_2)
        self.radioPre.setObjectName(_fromUtf8("radioPre"))
        self.gridlayout.addWidget(self.radioPre, 0, 0, 1, 1)
        self.radioSuff = QtGui.QRadioButton(self.groupBox_2)
        self.radioSuff.setObjectName(_fromUtf8("radioSuff"))
        self.gridlayout.addWidget(self.radioSuff, 0, 1, 1, 1)
        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridlayout.addWidget(self.label, 1, 0, 1, 1)
        self._2 = QtGui.QHBoxLayout()
        self._2.setObjectName(_fromUtf8("_2"))
        self.spinDigits = QtGui.QSpinBox(self.groupBox_2)
        self.spinDigits.setMaximum(3)
        self.spinDigits.setObjectName(_fromUtf8("spinDigits"))
        self._2.addWidget(self.spinDigits)
        spacerItem = QtGui.QSpacerItem(34, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self._2.addItem(spacerItem)
        self.gridlayout.addLayout(self._2, 1, 1, 1, 1)
        self.label_2 = QtGui.QLabel(self.groupBox_2)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridlayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.editLineSeparator = QtGui.QLineEdit(self.groupBox_2)
        self.editLineSeparator.setObjectName(_fromUtf8("editLineSeparator"))
        self.gridlayout.addWidget(self.editLineSeparator, 2, 1, 1, 1)
        self.checkKeepOldName = QtGui.QCheckBox(self.groupBox_2)
        self.checkKeepOldName.setObjectName(_fromUtf8("checkKeepOldName"))
        self.gridlayout.addWidget(self.checkKeepOldName, 3, 0, 1, 2)
        self.gridLayout.addWidget(self.groupBox_2, 0, 0, 1, 2)
        self.groupBox_3 = QtGui.QGroupBox(Number)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self._3 = QtGui.QGridLayout(self.groupBox_3)
        self._3.setObjectName(_fromUtf8("_3"))
        self.buttonStartNumbering = QtGui.QPushButton(self.groupBox_3)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonStartNumbering.sizePolicy().hasHeightForWidth())
        self.buttonStartNumbering.setSizePolicy(sizePolicy)
        self.buttonStartNumbering.setMinimumSize(QtCore.QSize(125, 0))
        self.buttonStartNumbering.setObjectName(_fromUtf8("buttonStartNumbering"))
        self._3.addWidget(self.buttonStartNumbering, 0, 0, 1, 1)
        self.gridLayout.addWidget(self.groupBox_3, 1, 0, 1, 1)

        self.retranslateUi(Number)
        QtCore.QMetaObject.connectSlotsByName(Number)

    def retranslateUi(self, Number):
        Number.setWindowTitle(QtGui.QApplication.translate("Number", "Number Images", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("Number", "Options", None, QtGui.QApplication.UnicodeUTF8))
        self.radioPre.setText(QtGui.QApplication.translate("Number", "Prefix", None, QtGui.QApplication.UnicodeUTF8))
        self.radioSuff.setText(QtGui.QApplication.translate("Number", "Suffix", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Number", "Digits:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Number", "Separator:", None, QtGui.QApplication.UnicodeUTF8))
        self.editLineSeparator.setText(QtGui.QApplication.translate("Number", "-", None, QtGui.QApplication.UnicodeUTF8))
        self.checkKeepOldName.setText(QtGui.QApplication.translate("Number", "Keep old filename", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("Number", "Numbering", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonStartNumbering.setText(QtGui.QApplication.translate("Number", "Start!", None, QtGui.QApplication.UnicodeUTF8))

