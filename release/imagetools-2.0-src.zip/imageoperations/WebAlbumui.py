# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\jorrit\development\python\imagetools\src\imageoperations\WebAlbumui.ui'
#
# Created: Sun Oct  9 14:56:59 2011
#      by: PyQt4 UI code generator 4.8.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_WebAlbum(object):
    def setupUi(self, WebAlbum):
        WebAlbum.setObjectName(_fromUtf8("WebAlbum"))
        WebAlbum.resize(312, 280)
        self.gridLayout = QtGui.QGridLayout(WebAlbum)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(WebAlbum)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.editTitle = QtGui.QLineEdit(WebAlbum)
        self.editTitle.setObjectName(_fromUtf8("editTitle"))
        self.gridLayout.addWidget(self.editTitle, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(WebAlbum)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.editDescription = QtGui.QLineEdit(WebAlbum)
        self.editDescription.setObjectName(_fromUtf8("editDescription"))
        self.gridLayout.addWidget(self.editDescription, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(WebAlbum)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.editLocation = QtGui.QLineEdit(WebAlbum)
        self.editLocation.setObjectName(_fromUtf8("editLocation"))
        self.gridLayout.addWidget(self.editLocation, 2, 1, 1, 1)
        self.btnCreate = QtGui.QPushButton(WebAlbum)
        self.btnCreate.setObjectName(_fromUtf8("btnCreate"))
        self.gridLayout.addWidget(self.btnCreate, 3, 0, 1, 2)
        self.btnCancel = QtGui.QPushButton(WebAlbum)
        self.btnCancel.setObjectName(_fromUtf8("btnCancel"))
        self.gridLayout.addWidget(self.btnCancel, 4, 0, 1, 2)
        self.progressBar = QtGui.QProgressBar(WebAlbum)
        self.progressBar.setProperty(_fromUtf8("value"), 0)
        self.progressBar.setTextVisible(False)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.gridLayout.addWidget(self.progressBar, 5, 0, 1, 2)
        self.textBox = QtGui.QPlainTextEdit(WebAlbum)
        self.textBox.setObjectName(_fromUtf8("textBox"))
        self.gridLayout.addWidget(self.textBox, 6, 0, 1, 2)

        self.retranslateUi(WebAlbum)
        QtCore.QMetaObject.connectSlotsByName(WebAlbum)

    def retranslateUi(self, WebAlbum):
        WebAlbum.setWindowTitle(QtGui.QApplication.translate("WebAlbum", "Web Album Generator", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("WebAlbum", "Album Title", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("WebAlbum", "Album Description", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("WebAlbum", "Location", None, QtGui.QApplication.UnicodeUTF8))
        self.btnCreate.setText(QtGui.QApplication.translate("WebAlbum", "Create webalbum", None, QtGui.QApplication.UnicodeUTF8))
        self.btnCancel.setText(QtGui.QApplication.translate("WebAlbum", "Cancel", None, QtGui.QApplication.UnicodeUTF8))

