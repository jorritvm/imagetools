'''
Created on 7-sep.-2011

@author: jorrit
'''

from PyQt4.QtGui import *
from PyQt4.QtCore import *


class ImageSelectionView(QTableView):

    def __init__(self, parent = None):
        QTableView.__init__(self, parent)
        
        """set the view to allow multiple selection"""
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)

        
    def removeImages(self):
        model = self.model()
        selmod = self.selectionModel()
        imageSelection = selmod.selectedIndexes()
        model.removeImages(imageSelection)
        
        
    def clearSelection(self):
        model = self.model()
        model.clearSelection()
        
        
    def resizeColumns(self, index, start, end):
        for i in range(4):
            self.resizeColumnToContents(i)