'''
Created on 7-sep.-2011

@author: jorrit
'''

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import imagetools


class ImageSelectionModel(QAbstractTableModel):

    """the image selection model holds the current working selection of images in the form of QFileInfo objects"""
    """the main idea is to have the same selectionmodel in the different parts of imagetools"""

    def __init__(self, parent = None):
        QTableView.__init__(self,parent)
        
        """the core data structure will be list of QFileInfo objects"""
        self.imagesInfo = list() 
        
        """we store the header data for the views"""
        self.headers = ["Filename","Size","Created","Last Modified"]
        
        
    def addImages(self, imagesList):
        """the argument imagesList contains a list of absolute filepaths"""
        for image in imagesList:
            self.addImage(image)
            
    
    def addImage(self, absoluteFilePath):
        """in this function we check for duplicity, generate qfileinfo objects, and finally call insertRows"""
        newImageInfo = QFileInfo(absoluteFilePath) 
        
        """check for duplicates"""
        if not self.isImageInSelection(newImageInfo):
            self.insertRows(newImageInfo)
       
        
    def isImageInSelection(self, newImageInfo):
        for imageInfo in self.imagesInfo:
            if newImageInfo == imageInfo:
                return True
        return False
    
    
    def removeImages(self, imageSelection):
        """translate the model indexes to a list of data objects"""
        toRemove = list()
        for imageIndex in imageSelection:
            row = imageIndex.row()
            toRemove.append(self.imagesInfo[row])
        
        for imageInfo in toRemove:
            self.removeRows(imageInfo)            
    
    
    def clearSelection(self):
        """this will wipe the dataset / selection clean"""
        toRemove = self.imagesInfo[:]
        for imageInfo in toRemove:
            self.removeRows(imageInfo)

    
    def getCurrentSelection(self):
        """returns the current selection"""
        return self.imagesInfo
    
    
    def adaptToRename(self, trackChanges):
        """changes the underlying data to use the new filenames"""
        i=0
        for oldFI in self.imagesInfo:
            absoluteFilePathImage = oldFI.absoluteFilePath()
            if absoluteFilePathImage in trackChanges.keys():
                """change the underlying data structure"""
                newAbsName = trackChanges[absoluteFilePathImage]
                newFi = QFileInfo(newAbsName)
                self.imagesInfo[i] = newFi                       
                """create a modelindex and let the views now that the data is changed"""
                index = self.createIndex(i, 0)
                self.dataChanged.emit(index, index)
            i+=1
            

    ## ABSTRACT MODEL REIMPLEMENATION
    """reimplement the abstract rowcount function"""
    def rowCount(self, index):    
        return len(self.imagesInfo)
    
    """reimplement the abstract columncount function"""
    def columnCount(self, index):
        return 4
    
    """reimplement the abstract columncount function"""
    def headerData(self, section, orientation, role):
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                
                if section < len(self.headers):
                    return self.headers[section]
                else:
                    return "not implemented"
                
    
    """reimplement the abstract data function"""
    def data(self, index, role):
        if role == Qt.DisplayRole:
            if index.column() == 0:
                return self.imagesInfo[index.row()].fileName()
            if index.column() == 1:
                return str(round(self.imagesInfo[index.row()].size()/1024/1024,2)) #returns megabytes
            if index.column() == 2:
                date = self.imagesInfo[index.row()].created().toString("yyyy-mm-dd")
                return date 
            if index.column() == 3:
                date = date = self.imagesInfo[index.row()].lastModified().toString("yyyy-mm-dd")
                return date
        
    def insertRows(self, newImageInfo):
        rc = self.rowCount(QModelIndex())
        self.beginInsertRows(QModelIndex(), rc, rc)
        
        self.imagesInfo.append(newImageInfo)
        
        self.endInsertRows()
        
    def removeRows(self, imageInfo):
        """allows you to remove one row from the model"""
        row = self.imagesInfo.index(imageInfo)
        
        self.beginRemoveRows(QModelIndex(), row, row)
        self.imagesInfo.pop(row)
        self.endRemoveRows()