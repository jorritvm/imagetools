+-----------------+
| Imagetools v2.0 |
+-----------------+
By Jorrit Vander Mynsbrugge


Description:
------------

Imagetools lets you number, rename and resize your pictures in a few simple clicks. 
You can also very easily create webalbums and upload them to your webspace via FTP. 


Changelog:
----------
v2.0
-recode using MVC principles
-revamped UI
-added web album feature
-thumbnailviewer
-multithreaded many processes

v1.1
-bugfixes in number section
-fixed 'no thumnbail bug' for windows users
-now comes with windows installer for dekstop integration

v1.0
-first release
-self extraction archive for windows
-source tarbal for unix


Installation instructions:
--------------------------

Windows:
-Run the installer, no dependencies are required.


Contact info:
-------------

Jorrit Vander Mynsbrugge
jorrit.vm@gmail.com
