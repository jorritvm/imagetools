# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'renamewindow.ui'
#
# Created: Wed Aug 22 18:51:07 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_renamewindow(object):
    def setupUi(self, renamewindow):
        renamewindow.setObjectName("renamewindow")
        renamewindow.resize(QtCore.QSize(QtCore.QRect(0,0,442,456).size()).expandedTo(renamewindow.minimumSizeHint()))

        self.vboxlayout = QtGui.QVBoxLayout(renamewindow)
        self.vboxlayout.setObjectName("vboxlayout")

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")

        spacerItem = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Preferred,QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem)

        self.labelimagepreview = QtGui.QLabel(renamewindow)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.labelimagepreview.sizePolicy().hasHeightForWidth())
        self.labelimagepreview.setSizePolicy(sizePolicy)
        self.labelimagepreview.setAlignment(QtCore.Qt.AlignCenter)
        self.labelimagepreview.setObjectName("labelimagepreview")
        self.hboxlayout.addWidget(self.labelimagepreview)

        spacerItem1 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Preferred,QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem1)
        self.vboxlayout.addLayout(self.hboxlayout)

        self.gridlayout = QtGui.QGridLayout()
        self.gridlayout.setObjectName("gridlayout")

        self.label = QtGui.QLabel(renamewindow)
        self.label.setObjectName("label")
        self.gridlayout.addWidget(self.label,0,0,1,1)

        self.labeloldname = QtGui.QLabel(renamewindow)
        self.labeloldname.setObjectName("labeloldname")
        self.gridlayout.addWidget(self.labeloldname,0,1,1,1)

        self.label_5 = QtGui.QLabel(renamewindow)
        self.label_5.setObjectName("label_5")
        self.gridlayout.addWidget(self.label_5,1,0,1,1)

        self.labelextension = QtGui.QLabel(renamewindow)
        self.labelextension.setObjectName("labelextension")
        self.gridlayout.addWidget(self.labelextension,1,1,1,1)

        self.label_4 = QtGui.QLabel(renamewindow)
        self.label_4.setObjectName("label_4")
        self.gridlayout.addWidget(self.label_4,2,0,1,1)

        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setObjectName("hboxlayout1")

        self.spinskipleft = QtGui.QSpinBox(renamewindow)
        self.spinskipleft.setObjectName("spinskipleft")
        self.hboxlayout1.addWidget(self.spinskipleft)

        spacerItem2 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout1.addItem(spacerItem2)
        self.gridlayout.addLayout(self.hboxlayout1,2,1,1,1)

        self.label_2 = QtGui.QLabel(renamewindow)
        self.label_2.setObjectName("label_2")
        self.gridlayout.addWidget(self.label_2,3,0,1,1)

        self.editnewname = QtGui.QLineEdit(renamewindow)
        self.editnewname.setObjectName("editnewname")
        self.gridlayout.addWidget(self.editnewname,3,1,1,1)

        self.label_3 = QtGui.QLabel(renamewindow)
        self.label_3.setObjectName("label_3")
        self.gridlayout.addWidget(self.label_3,4,0,1,1)

        self.labelpreview = QtGui.QLabel(renamewindow)
        self.labelpreview.setObjectName("labelpreview")
        self.gridlayout.addWidget(self.labelpreview,4,1,1,1)
        self.vboxlayout.addLayout(self.gridlayout)

        self.hboxlayout2 = QtGui.QHBoxLayout()
        self.hboxlayout2.setObjectName("hboxlayout2")

        self.buttonsavenext = QtGui.QPushButton(renamewindow)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonsavenext.sizePolicy().hasHeightForWidth())
        self.buttonsavenext.setSizePolicy(sizePolicy)
        self.buttonsavenext.setObjectName("buttonsavenext")
        self.hboxlayout2.addWidget(self.buttonsavenext)

        self.buttonskipnext = QtGui.QPushButton(renamewindow)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.buttonskipnext.sizePolicy().hasHeightForWidth())
        self.buttonskipnext.setSizePolicy(sizePolicy)
        self.buttonskipnext.setObjectName("buttonskipnext")
        self.hboxlayout2.addWidget(self.buttonskipnext)
        self.vboxlayout.addLayout(self.hboxlayout2)

        self.retranslateUi(renamewindow)
        QtCore.QMetaObject.connectSlotsByName(renamewindow)

    def retranslateUi(self, renamewindow):
        renamewindow.setWindowTitle(QtGui.QApplication.translate("renamewindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("renamewindow", "oldname", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("renamewindow", "extension", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("renamewindow", "skip left", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("renamewindow", "newname", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("renamewindow", "preview", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonsavenext.setText(QtGui.QApplication.translate("renamewindow", "Save - Next", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonskipnext.setText(QtGui.QApplication.translate("renamewindow", "Skip - Next", None, QtGui.QApplication.UnicodeUTF8))

