############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################


import os

from PyQt4.QtGui import *
from PyQt4.QtCore import *

from mainwindow import *

from leftwidget import *
from renamewidget import *
from welcomewidget import *
from numberwidget import *
from resizewidget import *

#wrapper class voor de Ui_mainwindow, hier kunnen we die aanpassen
class mainwindow(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        
        self.ui = Ui_mainwindow()
        self.ui.setupUi(self) #deze klasse meegeven aan de ui_klasse
        
        #toevoegen van de layouts in de frames 
        self.leftgridlayout = QGridLayout(self.ui.leftframe)
        self.leftgridlayout.setContentsMargins(0,0,0,0)
        self.rightgridlayout = QGridLayout(self.ui.rightframe)
        self.rightgridlayout.setContentsMargins(0,0,0,0)
                 
        #statusbar
        self.sb = QStatusBar(self)
        self.ui.gridlayout.addWidget(self.sb,1,0,1,2)
        
        #widgets
        self.createrightwidgets()
        self.showwelcomewidget()
        
        #slots
        self.setupslots()

        
    def createrightwidgets(self):
        self.leftwidget = leftwindow(self)
        
        self.welcomewidget = welcomewidget(self.leftwidget, self)
        self.numberwidget = numberwidget(self.leftwidget, self.sb, self)      
        self.renamewidget = renamewidget(self.leftwidget, self.sb, self)
        self.resizewidget = resizewidget(self.leftwidget, self.sb, self)
        
        self.welcomewidget.hide()
        self.numberwidget.hide()
        self.renamewidget.hide()
        self.resizewidget.hide()
        
        self.leftgridlayout.addWidget(self.leftwidget,0,0,1,1)
        self.rightgridlayout.addWidget(self.welcomewidget,0,1,1,1)
        self.rightgridlayout.addWidget(self.numberwidget,0,1,1,1)
        self.rightgridlayout.addWidget(self.renamewidget,0,1,1,1)
        self.rightgridlayout.addWidget(self.resizewidget,0,1,1,1)
        
       
    def showwelcomewidget(self):
        self.welcomewidget.show()
        self.numberwidget.hide()
        self.renamewidget.hide()
        self.resizewidget.hide()
        
    def shownumberwidget(self):
        self.welcomewidget.hide()
        self.numberwidget.show()
        self.renamewidget.hide()
        self.resizewidget.hide()
        
    def showrenamewidget(self):
        self.welcomewidget.hide()
        self.numberwidget.hide()
        self.renamewidget.show()    
        self.resizewidget.hide()
        
    def showresizewidget(self):
        self.welcomewidget.hide()
        self.numberwidget.hide()
        self.renamewidget.hide()    
        self.resizewidget.show()
        
    def showabout(self):
        QMessageBox.about(self, "About Imagetools","<h2>Imagetools 1.0</h2><p>GPL licensed - 2007<p>Imagetools provide you with the quickest way to resize & rename your images. It's free of charge, and can be spreaded freely. Any remarks can be mailed to the author, Jorrit Vander Mynsbrugge at jorrit.vm@telenet.be")
        
    def setupslots(self):
        QObject.connect(self.ui.actionHome,SIGNAL("triggered(bool)"),self.showwelcomewidget)
        QObject.connect(self.ui.actionNumber_Files,SIGNAL("triggered(bool)"),self.shownumberwidget)
        QObject.connect(self.ui.actionRename,SIGNAL("triggered(bool)"),self.showrenamewidget)
        QObject.connect(self.ui.actionResize,SIGNAL("triggered(bool)"),self.showresizewidget)
        QObject.connect(self.ui.actionAbout,SIGNAL("triggered(bool)"),self.showabout)
        
        
        
          
