from distutils.core import setup
import py2exe

setup(
    version = "1.0",
    description = "Imagetools Installation Script",
    name = "Imagetools",

    # targets to build
    windows = ["imagetools.py"],
    #console = ["hello.py"],
    )