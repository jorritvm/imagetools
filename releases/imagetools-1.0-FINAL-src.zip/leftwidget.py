############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from PyQt4.QtGui import *
from PyQt4.QtCore import *
from leftwindow import *

#wrapper class voor de Ui_leftwindow, hier kunnen we die aanpassen
class leftwindow(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        
        self.ui = Ui_leftwindow()
        self.ui.setupUi(self)  #deze klasse meegeven aan de ui_ klasse
        
        #slots
        QObject.connect(self.ui.buttonselectdir,SIGNAL("clicked(bool)"),self.filedialog)
        QObject.connect(self.ui.combosort,SIGNAL("currentIndexChanged(int)"),self.displaydircontent)
        QObject.connect(self.ui.checkreversed,SIGNAL("stateChanged(int)"),self.displaydircontent)
        QObject.connect(self.ui.lineEdit,SIGNAL("returnPressed()"),self.displaydircontent)
        QMetaObject.connectSlotsByName(self)
    
    #verzorgt de filedialog voor een map te selecten
    def filedialog(self):
        self.dialog = QFileDialog(self,QString("Select Imagesdirectory"),QString())
        self.dialog.setFileMode (QFileDialog.DirectoryOnly)
        
        self.dialog.show()
        
        QObject.connect(self.dialog,QtCore.SIGNAL("accepted()"),self.filedialogaccept)
        
        #fileName = QFileDialog.getOpenFileName(this,
     #tr("Open Image"), "/home/jana", tr("Image Files (*.png *.jpg *.bmp)"));
     
     
    #zorgt na een ingevoerde filedialog dat alle velden worden ingesteld
    def filedialogaccept(self):
        qlist = self.dialog.selectedFiles()
        qstr = qlist.first()
        
        #toevoegen aan lineedit
        self.ui.lineEdit.clear()
        self.ui.lineEdit.setText(qstr)
        
        self.displaydircontent()
        
    #haalt de dirinhoud op en toont deze, ingebouwde filter
    def displaydircontent(self):
        #dir managen met qt
        directory = QDir(self.ui.lineEdit.text())
        
        #namefilter: toon enkel pics
        namefilter = QStringList()
        namefilter.append("*.jpg")
        namefilter.append("*.JPG")
        namefilter.append("*.gif")
        namefilter.append("*.GIF")
        namefilter.append("*.png")
        namefilter.append("*.PNG")
        namefilter.append("*.bmp")
        namefilter.append("*.BMP")
        directory.setNameFilters(namefilter)
        
        #filefilter: toon enkel files
        directory.setFilter(QDir.Files)
        
        #sortfilter: afhankelijk van user input
        i = self.ui.combosort.currentIndex()
        p = self.ui.checkreversed.checkState()
        
        if i == 0:
            if p == Qt.Checked:
                directory.setSorting(QDir.Name | QDir.Reversed)
            else:
                directory.setSorting(QDir.Name)
        elif i == 1:
            if p == Qt.Checked:
                directory.setSorting(QDir.Type | QDir.Reversed)
            else:
                directory.setSorting(QDir.Type)
        elif i == 2:
            if p == Qt.Checked:
                directory.setSorting(QDir.Time | QDir.Reversed)
            else:
                directory.setSorting(QDir.Time)
        else: 
            if p == Qt.Checked:
                directory.setSorting(QDir.Name | QDir.Reversed)
            else:
                directory.setSorting(QDir.Name)
        
        #toevoegen aan de lijst
        self.ui.listWidget.clear()   
        filelist = directory.entryList()        
        for i in range(filelist.count()):
            self.ui.listWidget.addItem(filelist[i])

