############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from PyQt4.QtGui import *
from PyQt4.QtCore import *
from renamewindow import *


#wrapper class voor de Ui_rightwindow, hier kunnen we die aanpassen
class renamewidget(QWidget): #de wrapper is een widget: erft over van qwidget en heeft een parent
    def __init__(self, leftwidget, sb, parent=None):
        QWidget.__init__(self, parent)
        
        self.ui = Ui_renamewindow()
        self.ui.setupUi(self)  #deze klasse meegeven aan de ui_ klasse
        self.lw = leftwidget
        self.sb = sb
        
        QObject.connect(self.ui.editnewname,SIGNAL("textEdited(QString)"), self.adjustpreview)
        QObject.connect(self.ui.spinskipleft,SIGNAL("valueChanged(int)"), self.adjustpreview)
                
                
                
        QObject.connect(self.lw.ui.listWidget,SIGNAL("itemSelectionChanged()"),self.selecteditemchanged)
        QObject.connect(self.ui.buttonsavenext,SIGNAL("clicked()"), self.savenext)
        QObject.connect(self.ui.buttonskipnext,SIGNAL("clicked()"), self.gotonext)
        QObject.connect(self.ui.editnewname,SIGNAL("returnPressed()"), self.savenext)


    def showthumbnail(self, path):
        #aanmaken van de pixmap
        self.imagepreview = QPixmap(path) #een  qpixmap widget
        
        #plaatsen van de pixmap
        h = self.height() / 2
        transfotype = Qt.FastTransformation
        self.ui.labelimagepreview.setPixmap(self.imagepreview.scaledToHeight(h,transfotype))
        
        
    def adjustpreview(self):
        #samenstellen van de nieuwe filename
        leftkeep = self.ui.spinskipleft.value()
        oldname = self.ui.labeloldname.text()
        oldnamekeep = oldname.left(leftkeep)
        newpart = self.ui.editnewname.text()
        extension  = QString('.') + self.ui.labelextension.text()

        newname = oldnamekeep + newpart + extension
        self.ui.labelpreview.setText(newname)
        
    def selecteditemchanged(self):
        #ophalen in linkerdeel wat geselecteerd is en file object maken
        filepath = self.getfilepath()
        file = QFile(filepath)
        fileinfo = QFileInfo(filepath)
        
        #in rechterdeel de velden aanpassen
        self.showthumbnail(filepath)
        self.ui.labeloldname.setText(fileinfo.baseName())
        self.ui.labelextension.setText(fileinfo.completeSuffix())
        self.ui.editnewname.clear()
    
    def savenext(self):
        #haal nieuwe filename op
        nn = self.ui.labelpreview.text()
        newname = self.getnewfilepath()
                
        if nn == '':
            self.sb.showMessage(QString("Enter a filename first!"),3000)
        else:               
            #maak file object aan & rename
            filepath = self.getfilepath()
            file = QFile(filepath)
            x = file.rename(newname)
           
            if x:
                fileinfo = QFileInfo(newname)
                currentitem = self.lw.ui.listWidget.currentItem()
                currentitem.setText(fileinfo.fileName())
                self.sb.showMessage(QString("File Renamed!"),3000)
                self.gotonext()
            else:
                self.sb.showMessage(QString("Rename Failed!"),3000)
    
    
    def gotonext(self):
        p = self.lw.ui.listWidget.currentRow()
        self.lw.ui.listWidget.setCurrentRow(p + 1)
        self.ui.editnewname.setFocus()
        
    
    def getfilepath(self):
        currentitem = self.lw.ui.listWidget.currentItem().text()
        directory = QDir(self.lw.ui.lineEdit.text())
        filepath = directory.filePath(currentitem)
        return filepath
    
    def getnewfilepath(self):
        nn = self.ui.labelpreview.text()
        directory = QDir(self.lw.ui.lineEdit.text())
        filepath = directory.filePath(nn)
        return filepath