# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'resizewindow.ui'
#
# Created: Wed Aug 22 18:51:07 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_resizewindow(object):
    def setupUi(self, resizewindow):
        resizewindow.setObjectName("resizewindow")
        resizewindow.resize(QtCore.QSize(QtCore.QRect(0,0,624,588).size()).expandedTo(resizewindow.minimumSizeHint()))

        self.gridlayout = QtGui.QGridLayout(resizewindow)
        self.gridlayout.setObjectName("gridlayout")

        self.groupBox = QtGui.QGroupBox(resizewindow)
        self.groupBox.setMaximumSize(QtCore.QSize(280,16777215))
        self.groupBox.setObjectName("groupBox")

        self.gridlayout1 = QtGui.QGridLayout(self.groupBox)
        self.gridlayout1.setObjectName("gridlayout1")

        spacerItem = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout1.addItem(spacerItem,0,0,1,1)

        self.resizelist = QtGui.QListWidget(self.groupBox)
        self.resizelist.setObjectName("resizelist")
        self.gridlayout1.addWidget(self.resizelist,0,1,6,1)

        self.buttonaddone = QtGui.QPushButton(self.groupBox)
        self.buttonaddone.setObjectName("buttonaddone")
        self.gridlayout1.addWidget(self.buttonaddone,1,0,1,1)

        self.buttonremone = QtGui.QPushButton(self.groupBox)
        self.buttonremone.setObjectName("buttonremone")
        self.gridlayout1.addWidget(self.buttonremone,2,0,1,1)

        self.buttonaddall = QtGui.QPushButton(self.groupBox)
        self.buttonaddall.setObjectName("buttonaddall")
        self.gridlayout1.addWidget(self.buttonaddall,3,0,1,1)

        self.buttonremall = QtGui.QPushButton(self.groupBox)
        self.buttonremall.setObjectName("buttonremall")
        self.gridlayout1.addWidget(self.buttonremall,4,0,1,1)

        spacerItem1 = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout1.addItem(spacerItem1,5,0,1,1)
        self.gridlayout.addWidget(self.groupBox,0,0,3,1)

        self.groupBox_2 = QtGui.QGroupBox(resizewindow)
        self.groupBox_2.setObjectName("groupBox_2")

        self.gridlayout2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridlayout2.setObjectName("gridlayout2")

        self.label_5 = QtGui.QLabel(self.groupBox_2)
        self.label_5.setObjectName("label_5")
        self.gridlayout2.addWidget(self.label_5,0,0,1,1)

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setSpacing(1)
        self.hboxlayout.setObjectName("hboxlayout")

        self.editnameprefix = QtGui.QLineEdit(self.groupBox_2)
        self.editnameprefix.setObjectName("editnameprefix")
        self.hboxlayout.addWidget(self.editnameprefix)

        self.pushButton = QtGui.QPushButton(self.groupBox_2)
        self.pushButton.setMaximumSize(QtCore.QSize(25,25))
        self.pushButton.setObjectName("pushButton")
        self.hboxlayout.addWidget(self.pushButton)
        self.gridlayout2.addLayout(self.hboxlayout,0,1,1,1)

        self.label_2 = QtGui.QLabel(self.groupBox_2)
        self.label_2.setObjectName("label_2")
        self.gridlayout2.addWidget(self.label_2,1,0,1,1)

        self.hboxlayout1 = QtGui.QHBoxLayout()
        self.hboxlayout1.setSpacing(1)
        self.hboxlayout1.setObjectName("hboxlayout1")

        self.editnamesuffix = QtGui.QLineEdit(self.groupBox_2)
        self.editnamesuffix.setObjectName("editnamesuffix")
        self.hboxlayout1.addWidget(self.editnamesuffix)

        self.pushButton_2 = QtGui.QPushButton(self.groupBox_2)
        self.pushButton_2.setMaximumSize(QtCore.QSize(25,25))
        self.pushButton_2.setObjectName("pushButton_2")
        self.hboxlayout1.addWidget(self.pushButton_2)
        self.gridlayout2.addLayout(self.hboxlayout1,1,1,1,1)

        spacerItem2 = QtGui.QSpacerItem(20,21,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout2.addItem(spacerItem2,2,0,1,1)

        spacerItem3 = QtGui.QSpacerItem(20,21,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout2.addItem(spacerItem3,2,1,1,1)

        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setObjectName("label")
        self.gridlayout2.addWidget(self.label,3,0,1,1)

        self.hboxlayout2 = QtGui.QHBoxLayout()
        self.hboxlayout2.setObjectName("hboxlayout2")

        self.spinquality = QtGui.QSpinBox(self.groupBox_2)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed,QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.spinquality.sizePolicy().hasHeightForWidth())
        self.spinquality.setSizePolicy(sizePolicy)
        self.spinquality.setMinimum(0)
        self.spinquality.setMaximum(100)
        self.spinquality.setProperty("value",QtCore.QVariant(15))
        self.spinquality.setObjectName("spinquality")
        self.hboxlayout2.addWidget(self.spinquality)

        spacerItem4 = QtGui.QSpacerItem(34,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout2.addItem(spacerItem4)
        self.gridlayout2.addLayout(self.hboxlayout2,3,1,1,1)

        self.label_4 = QtGui.QLabel(self.groupBox_2)
        self.label_4.setObjectName("label_4")
        self.gridlayout2.addWidget(self.label_4,4,0,1,1)

        self.checksmooth = QtGui.QCheckBox(self.groupBox_2)
        self.checksmooth.setObjectName("checksmooth")
        self.gridlayout2.addWidget(self.checksmooth,4,1,1,1)

        spacerItem5 = QtGui.QSpacerItem(20,21,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout2.addItem(spacerItem5,5,0,1,1)

        spacerItem6 = QtGui.QSpacerItem(20,21,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout2.addItem(spacerItem6,5,1,1,1)

        self.label_3 = QtGui.QLabel(self.groupBox_2)
        self.label_3.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_3.setObjectName("label_3")
        self.gridlayout2.addWidget(self.label_3,6,0,1,1)

        self.gridlayout3 = QtGui.QGridLayout()
        self.gridlayout3.setObjectName("gridlayout3")

        self.rb1 = QtGui.QRadioButton(self.groupBox_2)
        self.rb1.setObjectName("rb1")
        self.gridlayout3.addWidget(self.rb1,0,0,1,1)

        self.comboBox = QtGui.QComboBox(self.groupBox_2)
        self.comboBox.setObjectName("comboBox")
        self.gridlayout3.addWidget(self.comboBox,0,1,1,1)

        self.rb2 = QtGui.QRadioButton(self.groupBox_2)
        self.rb2.setObjectName("rb2")
        self.gridlayout3.addWidget(self.rb2,1,0,1,1)

        self.vboxlayout = QtGui.QVBoxLayout()
        self.vboxlayout.setObjectName("vboxlayout")

        self.hboxlayout3 = QtGui.QHBoxLayout()
        self.hboxlayout3.setObjectName("hboxlayout3")

        spacerItem7 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout3.addItem(spacerItem7)

        self.labelquality = QtGui.QLabel(self.groupBox_2)
        self.labelquality.setObjectName("labelquality")
        self.hboxlayout3.addWidget(self.labelquality)

        spacerItem8 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout3.addItem(spacerItem8)
        self.vboxlayout.addLayout(self.hboxlayout3)

        self.qualityslider = QtGui.QSlider(self.groupBox_2)
        self.qualityslider.setMaximum(100)
        self.qualityslider.setProperty("value",QtCore.QVariant(50))
        self.qualityslider.setOrientation(QtCore.Qt.Horizontal)
        self.qualityslider.setObjectName("qualityslider")
        self.vboxlayout.addWidget(self.qualityslider)
        self.gridlayout3.addLayout(self.vboxlayout,1,1,1,1)

        self.rb3 = QtGui.QRadioButton(self.groupBox_2)
        self.rb3.setObjectName("rb3")
        self.gridlayout3.addWidget(self.rb3,2,0,1,1)

        self.editsize = QtGui.QLineEdit(self.groupBox_2)
        self.editsize.setObjectName("editsize")
        self.gridlayout3.addWidget(self.editsize,2,1,1,1)
        self.gridlayout2.addLayout(self.gridlayout3,6,1,1,1)
        self.gridlayout.addWidget(self.groupBox_2,0,1,1,1)

        self.groupBox_3 = QtGui.QGroupBox(resizewindow)
        self.groupBox_3.setObjectName("groupBox_3")

        self.gridlayout4 = QtGui.QGridLayout(self.groupBox_3)
        self.gridlayout4.setObjectName("gridlayout4")

        self.progressBar = QtGui.QProgressBar(self.groupBox_3)
        self.progressBar.setProperty("value",QtCore.QVariant(0))
        self.progressBar.setObjectName("progressBar")
        self.gridlayout4.addWidget(self.progressBar,0,0,1,3)

        spacerItem9 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.gridlayout4.addItem(spacerItem9,1,0,1,1)

        self.buttonstartresize = QtGui.QPushButton(self.groupBox_3)
        self.buttonstartresize.setObjectName("buttonstartresize")
        self.gridlayout4.addWidget(self.buttonstartresize,1,1,1,1)

        spacerItem10 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.gridlayout4.addItem(spacerItem10,1,2,1,1)
        self.gridlayout.addWidget(self.groupBox_3,1,1,1,1)

        spacerItem11 = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem11,2,1,1,1)

        self.retranslateUi(resizewindow)
        QtCore.QObject.connect(self.buttonremall,QtCore.SIGNAL("clicked()"),self.resizelist.clear)
        QtCore.QObject.connect(self.pushButton,QtCore.SIGNAL("clicked()"),self.editnameprefix.clear)
        QtCore.QObject.connect(self.pushButton_2,QtCore.SIGNAL("clicked()"),self.editnamesuffix.clear)
        QtCore.QMetaObject.connectSlotsByName(resizewindow)

    def retranslateUi(self, resizewindow):
        resizewindow.setWindowTitle(QtGui.QApplication.translate("resizewindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("resizewindow", "Select", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonaddone.setText(QtGui.QApplication.translate("resizewindow", ">", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonremone.setText(QtGui.QApplication.translate("resizewindow", "<", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonaddall.setText(QtGui.QApplication.translate("resizewindow", "ALL", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonremall.setText(QtGui.QApplication.translate("resizewindow", "None", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("resizewindow", "Options", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("resizewindow", "Name prefix:", None, QtGui.QApplication.UnicodeUTF8))
        self.editnameprefix.setText(QtGui.QApplication.translate("resizewindow", "small_", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setText(QtGui.QApplication.translate("resizewindow", "X", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("resizewindow", "Name suffix:", None, QtGui.QApplication.UnicodeUTF8))
        self.editnamesuffix.setText(QtGui.QApplication.translate("resizewindow", "_small", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_2.setText(QtGui.QApplication.translate("resizewindow", "X", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("resizewindow", "Compression:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("resizewindow", "Quality:", None, QtGui.QApplication.UnicodeUTF8))
        self.checksmooth.setText(QtGui.QApplication.translate("resizewindow", "Smoothing", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("resizewindow", "Size:", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 1280x960", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 1024x768", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 800x600", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 640x480", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 320x240", None, QtGui.QApplication.UnicodeUTF8))
        self.comboBox.addItem(QtGui.QApplication.translate("resizewindow", "Photo: 160x120", None, QtGui.QApplication.UnicodeUTF8))
        self.labelquality.setText(QtGui.QApplication.translate("resizewindow", "50 %", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("resizewindow", "Resize", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonstartresize.setText(QtGui.QApplication.translate("resizewindow", "Start!", None, QtGui.QApplication.UnicodeUTF8))

