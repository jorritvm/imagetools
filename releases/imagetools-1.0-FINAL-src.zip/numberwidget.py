############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from PyQt4.QtGui import *
from PyQt4.QtCore import *
from numberwindow import *


#wrapper class voor de Ui_rightwindow, hier kunnen we die aanpassen
class numberwidget(QWidget): #de wrapper is een widget: erft over van qwidget en heeft een parent
    def __init__(self, leftwidget, sb, parent=None):
        QWidget.__init__(self, parent)
        
        self.ui = Ui_numberwindow()
        self.ui.setupUi(self)  #deze klasse meegeven aan de ui_ klasse
        self.lw = leftwidget        
        self.sb = sb

        self.setupslots()
        
        
    def setupslots(self):
        QObject.connect(self.ui.buttonaddone, SIGNAL("clicked()"),self.addone)
        QObject.connect(self.ui.buttonremone, SIGNAL("clicked()"),self.remone)
        QObject.connect(self.ui.buttonaddall, SIGNAL("clicked()"),self.addall)
        QObject.connect(self.ui.buttonstartnumbering, SIGNAL("clicked()"),self.startnumbering)
        
    def addone(self):
        item = self.lw.ui.listWidget.currentItem()
        self.ui.numberlist.addItem(item.text())
    
    def remone(self):
        #item = self.ui.numberlist.currentRow()
        item = self.ui.numberlist.selectedItems()
        if len(item) > 0:
            item = item[0]
            row = self.ui.numberlist.row(item)
            self.ui.numberlist.takeItem(row)
        else:
            self.sb.showMessage('Select an item to remove from list first!',3000)
    
    def addall(self):
        self.ui.numberlist.clear()
        for i in range(0,self.lw.ui.listWidget.count()):
            item = self.lw.ui.listWidget.item(i)
            self.ui.numberlist.addItem(item.text())

    def startnumbering(self):
        print "we starten numbering procedure"
        if self.ui.radiopre.isChecked():
            addto = 0
        elif self.ui.radiosuff.isChecked():
            addto = 1
        else: 
            self.sb.showMessage('Select prefix or suffix mode!',3000)
            return
        digits = self.ui.spindigits.value()
        sep = self.ui.editlineseparator.text()
        if self.ui.checkkeepoldname.isChecked():
            keepold = 1
        else:
            keepold = 0
            
        print 'items in list' + str(self.ui.numberlist.count())
        for i in range(1, self.ui.numberlist.count()+1):
            newname = ''
            item = self.ui.numberlist.takeItem(0)
            directory = QDir(self.lw.ui.lineEdit.text())
            path = directory.filePath(item.text())
            fi = QFileInfo(path)
            file = QFile(path)
            ext = fi.completeSuffix()
            
            if digits == 3 and i < 10:
                newname = '00'
            elif digits == 3 and 10 < i < 100:
                newname = '0'
            elif digits == 2 and i < 10:
                newname = '0'
            
            if digits:
                newname += str(i)
            
            
            if not addto: #prefix
                if digits:
                    newname += sep
            
                if keepold:
                    newname += fi.fileName()
                else:
                    newname += ext
                    
            else: #suffix
               if digits:
                   newname = sep + newname
               if keepold:
                   newname = fi.baseName()+newname+ext
               else:
                   newname += '.'
                   newname += ext
            
                       
            path = directory.filePath(newname)
            
            x = file.rename(path)
           
            if x:
                self.sb.showMessage(QString("Rename success!"),3000)
            else:
                self.sb.showMessage(QString("Rename Failed!"),3000)
            
        self.lw.displaydircontent()
        
        
        
    