# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'welcomewindow.ui'
#
# Created: Wed Aug 22 18:51:07 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_welcomewindow(object):
    def setupUi(self, welcomewindow):
        welcomewindow.setObjectName("welcomewindow")
        welcomewindow.resize(QtCore.QSize(QtCore.QRect(0,0,576,452).size()).expandedTo(welcomewindow.minimumSizeHint()))

        self.gridlayout = QtGui.QGridLayout(welcomewindow)
        self.gridlayout.setContentsMargins(30,-1,30,-1)
        self.gridlayout.setObjectName("gridlayout")

        self.label = QtGui.QLabel(welcomewindow)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.gridlayout.addWidget(self.label,0,0,1,1)

        self.retranslateUi(welcomewindow)
        QtCore.QMetaObject.connectSlotsByName(welcomewindow)

    def retranslateUi(self, welcomewindow):
        welcomewindow.setWindowTitle(QtGui.QApplication.translate("welcomewindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("welcomewindow", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'Sans Serif\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\" margin-top:16px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:x-large; font-weight:600;\"><span style=\" font-size:x-large;\">Imagetools 1.0</span></p>\n"
        "<p style=\" margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:large; font-weight:600;\"><span style=\" font-size:large;\">by Jorrit Vander Mynsbrugge</span></p>\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:large; font-weight:600;\"></p>\n"
        "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">This program allows you to quickly number, rename and resize your images, ideal for occasions where you want to add a quick note to your pictures without screwing up the chronological order. </p>\n"
        "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">The GUI is pretty straigthforward. Start by selecting Tools-Number. When you\'re done numbering select Tools-Rename, and finally Tools-Resize. </p>\n"
        "<p style=\"-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
        "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Greetings, </p>\n"
        "<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">The author</p></body></html>", None, QtGui.QApplication.UnicodeUTF8))

