# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'leftwindow.ui'
#
# Created: Wed Aug 22 18:51:06 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_leftwindow(object):
    def setupUi(self, leftwindow):
        leftwindow.setObjectName("leftwindow")
        leftwindow.resize(QtCore.QSize(QtCore.QRect(0,0,358,505).size()).expandedTo(leftwindow.minimumSizeHint()))

        self.vboxlayout = QtGui.QVBoxLayout(leftwindow)
        self.vboxlayout.setObjectName("vboxlayout")

        self.groupBox_2 = QtGui.QGroupBox(leftwindow)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupBox_2.sizePolicy().hasHeightForWidth())
        self.groupBox_2.setSizePolicy(sizePolicy)
        self.groupBox_2.setObjectName("groupBox_2")

        self.gridlayout = QtGui.QGridLayout(self.groupBox_2)
        self.gridlayout.setObjectName("gridlayout")

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")

        self.lineEdit = QtGui.QLineEdit(self.groupBox_2)
        self.lineEdit.setObjectName("lineEdit")
        self.hboxlayout.addWidget(self.lineEdit)

        self.buttonselectdir = QtGui.QPushButton(self.groupBox_2)
        self.buttonselectdir.setMaximumSize(QtCore.QSize(25,16777215))
        self.buttonselectdir.setObjectName("buttonselectdir")
        self.hboxlayout.addWidget(self.buttonselectdir)
        self.gridlayout.addLayout(self.hboxlayout,0,0,1,1)
        self.vboxlayout.addWidget(self.groupBox_2)

        self.groupBox = QtGui.QGroupBox(leftwindow)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.groupBox.sizePolicy().hasHeightForWidth())
        self.groupBox.setSizePolicy(sizePolicy)
        self.groupBox.setObjectName("groupBox")

        self.vboxlayout1 = QtGui.QVBoxLayout(self.groupBox)
        self.vboxlayout1.setObjectName("vboxlayout1")

        self.combosort = QtGui.QComboBox(self.groupBox)
        self.combosort.setObjectName("combosort")
        self.vboxlayout1.addWidget(self.combosort)

        self.checkreversed = QtGui.QCheckBox(self.groupBox)
        self.checkreversed.setObjectName("checkreversed")
        self.vboxlayout1.addWidget(self.checkreversed)
        self.vboxlayout.addWidget(self.groupBox)

        self.groupBox_3 = QtGui.QGroupBox(leftwindow)
        self.groupBox_3.setObjectName("groupBox_3")

        self.gridlayout1 = QtGui.QGridLayout(self.groupBox_3)
        self.gridlayout1.setObjectName("gridlayout1")

        self.listWidget = QtGui.QListWidget(self.groupBox_3)
        self.listWidget.setObjectName("listWidget")
        self.gridlayout1.addWidget(self.listWidget,0,0,1,1)
        self.vboxlayout.addWidget(self.groupBox_3)

        self.retranslateUi(leftwindow)
        QtCore.QMetaObject.connectSlotsByName(leftwindow)

    def retranslateUi(self, leftwindow):
        leftwindow.setWindowTitle(QtGui.QApplication.translate("leftwindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("leftwindow", "Directory", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonselectdir.setText(QtGui.QApplication.translate("leftwindow", "...", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("leftwindow", "Sort", None, QtGui.QApplication.UnicodeUTF8))
        self.combosort.addItem(QtGui.QApplication.translate("leftwindow", "Name", None, QtGui.QApplication.UnicodeUTF8))
        self.combosort.addItem(QtGui.QApplication.translate("leftwindow", "Type", None, QtGui.QApplication.UnicodeUTF8))
        self.combosort.addItem(QtGui.QApplication.translate("leftwindow", "Date Modified", None, QtGui.QApplication.UnicodeUTF8))
        self.checkreversed.setText(QtGui.QApplication.translate("leftwindow", "Reversed", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("leftwindow", "Files", None, QtGui.QApplication.UnicodeUTF8))

