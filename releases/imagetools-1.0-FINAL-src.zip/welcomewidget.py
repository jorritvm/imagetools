############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from PyQt4.QtGui import *
from PyQt4.QtCore import *
from welcomewindow import *


#wrapper class voor de Ui_rightwindow, hier kunnen we die aanpassen
class welcomewidget(QWidget): #de wrapper is een widget: erft over van qwidget en heeft een parent
    def __init__(self, leftwidget, parent=None):
        QWidget.__init__(self, parent)
        
        self.ui = Ui_welcomewindow()
        self.ui.setupUi(self)  #deze klasse meegeven aan de ui_ klasse
        self.lw = leftwidget
