############################################################################
#    Copyright (C) 2007 by Jorrit Vander Mynsbrugge                        #
#    jorrit.vm@telenet.be                                                  #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################


from PyQt4.QtGui import *
from PyQt4.QtCore import *
from resizewindow import *


#wrapper class voor de Ui_rightwindow, hier kunnen we die aanpassen
class resizewidget(QWidget): #de wrapper is een widget: erft over van qwidget en heeft een parent
    def __init__(self, leftwidget, sb, parent=None):
        QWidget.__init__(self, parent)
        
        self.ui = Ui_resizewindow()
        self.ui.setupUi(self)  #deze klasse meegeven aan de ui_ klasse
        self.lw = leftwidget        
        self.sb = sb

        self.setupslots()
        
        
    def setupslots(self):
        QObject.connect(self.ui.buttonaddone, SIGNAL("clicked()"),self.addone)
        QObject.connect(self.ui.buttonremone, SIGNAL("clicked()"),self.remone)
        QObject.connect(self.ui.buttonaddall, SIGNAL("clicked()"),self.addall)
        QObject.connect(self.ui.buttonstartresize, SIGNAL("clicked()"),self.startresize)
        QObject.connect(self.ui.qualityslider, SIGNAL("valueChanged(int)"),self.adjustslider)
        
    def addone(self):
        item = self.lw.ui.listWidget.currentItem()
        self.ui.resizelist.addItem(item.text())
    
    def remone(self):
        #item = self.ui.resizelist.currentRow()
        item = self.ui.resizelist.selectedItems()
        if len(item) > 0:
            item = item[0]
            row = self.ui.resizelist.row(item)
            self.ui.resizelist.takeItem(row)
        else:
            self.sb.showMessage('Select an item to remove from list first!',3000)
    
    def addall(self):
        self.ui.resizelist.clear()
        for i in range(0,self.lw.ui.listWidget.count()):
            item = self.lw.ui.listWidget.item(i)
            self.ui.resizelist.addItem(item.text())

    def startresize(self):
       
        #quality ref
        quality = 100 - self.ui.spinquality.value()
        
        if self.ui.checksmooth.isChecked():
            smooth = Qt.SmoothTransformation
        else:
            smooth = Qt.FastTransformation
        
        total = self.ui.resizelist.count()
        for i in range(1, self.ui.resizelist.count()+1):
            #creeer de nodige objecten
            item = self.ui.resizelist.takeItem(0)
            directory = QDir(self.lw.ui.lineEdit.text())
            path = directory.filePath(item.text())
            fileinfo = QFileInfo(path)
            #file = QFile(path)
            image = QImage(path)
            newname = ''
            
            #creeer de nieuwe naam
            newname += self.ui.editnameprefix.text()
            newname += fileinfo.baseName()
            newname += self.ui.editnamesuffix.text()
            newname += "."
            newname += fileinfo.completeSuffix()
            newname = directory.filePath(newname)

            #size bepalen
            if self.ui.rb1.isChecked():
                x = self.ui.comboBox.currentIndex()
                if x == 0:
                    w = 1280 
                    h = 1024
                elif x == 1:
                    w = 1280 
                    h = 1024
                elif x == 2:
                    w = 800 
                    h = 600
                elif x == 3:
                    w = 640 
                    h = 480
                elif x == 4:
                    w = 320 
                    h = 240
                elif x == 5:
                    w = 160 
                    h = 120
            elif self.ui.rb2.isChecked():
                sizeproc = self.ui.qualityslider.value() 
                w = image.width() * sizeproc / 100
                h = image.height() * sizeproc / 100
            elif self.ui.rb3.isChecked():
                string = self.ui.editsize.text()
                slist = string.split("x")
                if len(slist) == 2:
                    w = int(slist[0])
                    h = int(slist[1])
                else:
                    self.sb.showMessage("Enter size formatted like 'WIDTHxHEIGHT'!",3000)       
            else:
                self.sb.showMessage('Select size preference!',3000)       
                
            #resize  
            newimage = image.scaled(w, h, Qt.KeepAspectRatio, smooth)
            newimage.save(newname, '', quality)
            
            #progressbar aanpassen
            value = i * 100 / total
            self.ui.progressBar.setValue(value)
           
     
        self.lw.displaydircontent()
        
    def adjustslider(self, x):
        self.ui.labelquality.setText(str(x)+' %')
        
    