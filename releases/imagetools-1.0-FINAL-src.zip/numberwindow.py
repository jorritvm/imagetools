# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'numberwindow.ui'
#
# Created: Wed Aug 22 18:51:07 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_numberwindow(object):
    def setupUi(self, numberwindow):
        numberwindow.setObjectName("numberwindow")
        numberwindow.resize(QtCore.QSize(QtCore.QRect(0,0,597,489).size()).expandedTo(numberwindow.minimumSizeHint()))

        self.gridlayout = QtGui.QGridLayout(numberwindow)
        self.gridlayout.setObjectName("gridlayout")

        self.groupBox = QtGui.QGroupBox(numberwindow)
        self.groupBox.setMaximumSize(QtCore.QSize(280,16777215))
        self.groupBox.setObjectName("groupBox")

        self.gridlayout1 = QtGui.QGridLayout(self.groupBox)
        self.gridlayout1.setObjectName("gridlayout1")

        spacerItem = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout1.addItem(spacerItem,0,0,1,1)

        self.numberlist = QtGui.QListWidget(self.groupBox)
        self.numberlist.setObjectName("numberlist")
        self.gridlayout1.addWidget(self.numberlist,0,1,6,1)

        self.buttonaddone = QtGui.QPushButton(self.groupBox)
        self.buttonaddone.setObjectName("buttonaddone")
        self.gridlayout1.addWidget(self.buttonaddone,1,0,1,1)

        self.buttonremone = QtGui.QPushButton(self.groupBox)
        self.buttonremone.setObjectName("buttonremone")
        self.gridlayout1.addWidget(self.buttonremone,2,0,1,1)

        self.buttonaddall = QtGui.QPushButton(self.groupBox)
        self.buttonaddall.setObjectName("buttonaddall")
        self.gridlayout1.addWidget(self.buttonaddall,3,0,1,1)

        self.buttonremall = QtGui.QPushButton(self.groupBox)
        self.buttonremall.setObjectName("buttonremall")
        self.gridlayout1.addWidget(self.buttonremall,4,0,1,1)

        spacerItem1 = QtGui.QSpacerItem(20,40,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout1.addItem(spacerItem1,5,0,1,1)
        self.gridlayout.addWidget(self.groupBox,0,0,3,1)

        self.groupBox_2 = QtGui.QGroupBox(numberwindow)
        self.groupBox_2.setObjectName("groupBox_2")

        self.gridlayout2 = QtGui.QGridLayout(self.groupBox_2)
        self.gridlayout2.setObjectName("gridlayout2")

        self.radiopre = QtGui.QRadioButton(self.groupBox_2)
        self.radiopre.setObjectName("radiopre")
        self.gridlayout2.addWidget(self.radiopre,0,0,1,1)

        self.radiosuff = QtGui.QRadioButton(self.groupBox_2)
        self.radiosuff.setObjectName("radiosuff")
        self.gridlayout2.addWidget(self.radiosuff,0,1,1,1)

        self.label = QtGui.QLabel(self.groupBox_2)
        self.label.setObjectName("label")
        self.gridlayout2.addWidget(self.label,1,0,1,1)

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setObjectName("hboxlayout")

        self.spindigits = QtGui.QSpinBox(self.groupBox_2)
        self.spindigits.setMaximum(3)
        self.spindigits.setObjectName("spindigits")
        self.hboxlayout.addWidget(self.spindigits)

        spacerItem2 = QtGui.QSpacerItem(34,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout.addItem(spacerItem2)
        self.gridlayout2.addLayout(self.hboxlayout,1,1,1,1)

        self.label_2 = QtGui.QLabel(self.groupBox_2)
        self.label_2.setObjectName("label_2")
        self.gridlayout2.addWidget(self.label_2,2,0,1,1)

        self.editlineseparator = QtGui.QLineEdit(self.groupBox_2)
        self.editlineseparator.setObjectName("editlineseparator")
        self.gridlayout2.addWidget(self.editlineseparator,2,1,1,1)

        self.checkkeepoldname = QtGui.QCheckBox(self.groupBox_2)
        self.checkkeepoldname.setObjectName("checkkeepoldname")
        self.gridlayout2.addWidget(self.checkkeepoldname,3,0,1,2)
        self.gridlayout.addWidget(self.groupBox_2,0,1,1,2)

        spacerItem3 = QtGui.QSpacerItem(61,90,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.gridlayout.addItem(spacerItem3,0,3,1,1)

        self.groupBox_3 = QtGui.QGroupBox(numberwindow)
        self.groupBox_3.setObjectName("groupBox_3")

        self.gridlayout3 = QtGui.QGridLayout(self.groupBox_3)
        self.gridlayout3.setObjectName("gridlayout3")

        self.buttonstartnumbering = QtGui.QPushButton(self.groupBox_3)
        self.buttonstartnumbering.setObjectName("buttonstartnumbering")
        self.gridlayout3.addWidget(self.buttonstartnumbering,0,0,1,1)
        self.gridlayout.addWidget(self.groupBox_3,1,1,1,1)

        spacerItem4 = QtGui.QSpacerItem(81,64,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.gridlayout.addItem(spacerItem4,1,2,1,2)

        spacerItem5 = QtGui.QSpacerItem(145,181,QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem5,2,1,1,1)

        self.retranslateUi(numberwindow)
        QtCore.QObject.connect(self.buttonremall,QtCore.SIGNAL("clicked(bool)"),self.numberlist.clear)
        QtCore.QMetaObject.connectSlotsByName(numberwindow)

    def retranslateUi(self, numberwindow):
        numberwindow.setWindowTitle(QtGui.QApplication.translate("numberwindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("numberwindow", "Select", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonaddone.setText(QtGui.QApplication.translate("numberwindow", ">", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonremone.setText(QtGui.QApplication.translate("numberwindow", "<", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonaddall.setText(QtGui.QApplication.translate("numberwindow", "ALL", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonremall.setText(QtGui.QApplication.translate("numberwindow", "None", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("numberwindow", "Options", None, QtGui.QApplication.UnicodeUTF8))
        self.radiopre.setText(QtGui.QApplication.translate("numberwindow", "Prefix", None, QtGui.QApplication.UnicodeUTF8))
        self.radiosuff.setText(QtGui.QApplication.translate("numberwindow", "Suffix", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("numberwindow", "Digits:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("numberwindow", "Separator:", None, QtGui.QApplication.UnicodeUTF8))
        self.editlineseparator.setText(QtGui.QApplication.translate("numberwindow", "-", None, QtGui.QApplication.UnicodeUTF8))
        self.checkkeepoldname.setText(QtGui.QApplication.translate("numberwindow", "Keep old filename", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("numberwindow", "Numbering", None, QtGui.QApplication.UnicodeUTF8))
        self.buttonstartnumbering.setText(QtGui.QApplication.translate("numberwindow", "Start!", None, QtGui.QApplication.UnicodeUTF8))

