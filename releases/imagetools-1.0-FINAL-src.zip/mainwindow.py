# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created: Wed Aug 22 18:51:06 2007
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_mainwindow(object):
    def setupUi(self, mainwindow):
        mainwindow.setObjectName("mainwindow")
        mainwindow.resize(QtCore.QSize(QtCore.QRect(0,0,809,618).size()).expandedTo(mainwindow.minimumSizeHint()))

        self.centralwidget = QtGui.QWidget(mainwindow)
        self.centralwidget.setObjectName("centralwidget")

        self.gridlayout = QtGui.QGridLayout(self.centralwidget)
        self.gridlayout.setMargin(0)
        self.gridlayout.setSpacing(0)
        self.gridlayout.setObjectName("gridlayout")

        self.leftframe = QtGui.QFrame(self.centralwidget)
        self.leftframe.setMaximumSize(QtCore.QSize(220,16777215))
        self.leftframe.setBaseSize(QtCore.QSize(200,0))
        self.leftframe.setFrameShape(QtGui.QFrame.NoFrame)
        self.leftframe.setFrameShadow(QtGui.QFrame.Plain)
        self.leftframe.setObjectName("leftframe")
        self.gridlayout.addWidget(self.leftframe,0,0,1,1)

        self.rightframe = QtGui.QFrame(self.centralwidget)
        self.rightframe.setFrameShape(QtGui.QFrame.NoFrame)
        self.rightframe.setFrameShadow(QtGui.QFrame.Plain)
        self.rightframe.setObjectName("rightframe")
        self.gridlayout.addWidget(self.rightframe,0,1,1,1)
        mainwindow.setCentralWidget(self.centralwidget)

        self.menubar = QtGui.QMenuBar(mainwindow)
        self.menubar.setGeometry(QtCore.QRect(0,0,809,29))
        self.menubar.setObjectName("menubar")

        self.menuFile = QtGui.QMenu(self.menubar)
        self.menuFile.setObjectName("menuFile")

        self.menuTools = QtGui.QMenu(self.menubar)
        self.menuTools.setObjectName("menuTools")

        self.menuHelp = QtGui.QMenu(self.menubar)
        self.menuHelp.setObjectName("menuHelp")
        mainwindow.setMenuBar(self.menubar)

        self.actionAbout = QtGui.QAction(mainwindow)
        self.actionAbout.setObjectName("actionAbout")

        self.actionNumber_Files = QtGui.QAction(mainwindow)
        self.actionNumber_Files.setObjectName("actionNumber_Files")

        self.actionResize = QtGui.QAction(mainwindow)
        self.actionResize.setObjectName("actionResize")

        self.actionPreferences = QtGui.QAction(mainwindow)
        self.actionPreferences.setObjectName("actionPreferences")

        self.actionQuit = QtGui.QAction(mainwindow)
        self.actionQuit.setObjectName("actionQuit")

        self.actionRename = QtGui.QAction(mainwindow)
        self.actionRename.setObjectName("actionRename")

        self.actionHome = QtGui.QAction(mainwindow)
        self.actionHome.setObjectName("actionHome")
        self.menuFile.addAction(self.actionQuit)
        self.menuTools.addAction(self.actionHome)
        self.menuTools.addSeparator()
        self.menuTools.addAction(self.actionNumber_Files)
        self.menuTools.addAction(self.actionRename)
        self.menuTools.addAction(self.actionResize)
        self.menuTools.addSeparator()
        self.menuHelp.addAction(self.actionAbout)
        self.menubar.addAction(self.menuFile.menuAction())
        self.menubar.addAction(self.menuTools.menuAction())
        self.menubar.addAction(self.menuHelp.menuAction())

        self.retranslateUi(mainwindow)
        QtCore.QObject.connect(self.actionQuit,QtCore.SIGNAL("triggered()"),mainwindow.close)
        QtCore.QMetaObject.connectSlotsByName(mainwindow)

    def retranslateUi(self, mainwindow):
        mainwindow.setWindowTitle(QtGui.QApplication.translate("mainwindow", "Imagetools", None, QtGui.QApplication.UnicodeUTF8))
        self.menuFile.setTitle(QtGui.QApplication.translate("mainwindow", "File", None, QtGui.QApplication.UnicodeUTF8))
        self.menuTools.setTitle(QtGui.QApplication.translate("mainwindow", "Tools", None, QtGui.QApplication.UnicodeUTF8))
        self.menuHelp.setTitle(QtGui.QApplication.translate("mainwindow", "Help", None, QtGui.QApplication.UnicodeUTF8))
        self.actionAbout.setText(QtGui.QApplication.translate("mainwindow", "About", None, QtGui.QApplication.UnicodeUTF8))
        self.actionNumber_Files.setText(QtGui.QApplication.translate("mainwindow", "Number", None, QtGui.QApplication.UnicodeUTF8))
        self.actionResize.setText(QtGui.QApplication.translate("mainwindow", "Resize", None, QtGui.QApplication.UnicodeUTF8))
        self.actionPreferences.setText(QtGui.QApplication.translate("mainwindow", "Preferences", None, QtGui.QApplication.UnicodeUTF8))
        self.actionQuit.setText(QtGui.QApplication.translate("mainwindow", "Quit", None, QtGui.QApplication.UnicodeUTF8))
        self.actionRename.setText(QtGui.QApplication.translate("mainwindow", "Rename", None, QtGui.QApplication.UnicodeUTF8))
        self.actionHome.setText(QtGui.QApplication.translate("mainwindow", "Home", None, QtGui.QApplication.UnicodeUTF8))

